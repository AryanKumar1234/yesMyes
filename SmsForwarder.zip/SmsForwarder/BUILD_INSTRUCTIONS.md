# SMS Forwarder – Build & Update Guide

## App info
| Field          | Value                |
|----------------|----------------------|
| Package name   | `com.smsforwarder`   |
| Min Android    | 5.0 (API 21)         |
| Version code   | 2 (update from v1)   |

---

## First-time build (fresh install)

### 1. Generate your signing keystore
```bash
chmod +x generate_keystore.sh
./generate_keystore.sh
```
⚠️ **Back up `smsforwarder-release.jks` and `keystore.properties` somewhere safe.**
You need the SAME keystore for every future update.

### 2. Build the release APK
**Option A – Android Studio**
- File → Open → select this folder
- Build → Generate Signed Bundle / APK → APK → use existing keystore → Release

**Option B – command line** (requires Android SDK + JDK 11/17)
```bash
./gradlew assembleRelease
```
APK: `app/build/outputs/apk/release/app-release.apk`

### 3. Install
```bash
# via ADB
adb install app/build/outputs/apk/release/app-release.apk

# or copy to phone and open the file
```

---

## Updating an existing install

For the update to succeed **all three must match**:

| Requirement            | How to check / fix                         |
|------------------------|--------------------------------------------|
| Same package name      | Must be `com.smsforwarder` – never change  |
| Same signing cert      | Use the same `smsforwarder-release.jks`    |
| Higher `versionCode`   | Increase the number in `app/build.gradle`  |

```bash
# Bump versionCode in app/build.gradle, then:
./gradlew assembleRelease
adb install -r app/build/outputs/apk/release/app-release.apk
#             ↑ -r = replace / update
```

---

## If you lost the original keystore

You cannot update in-place. You must:
1. Uninstall the old app (settings are lost)
2. Generate a new keystore with `generate_keystore.sh`
3. Fresh install the new APK

---

## Forwarding channels

| Channel  | Requires                          |
|----------|-----------------------------------|
| SMS      | SEND_SMS permission               |
| Telegram | Bot token + Chat ID from @BotFather + @userinfobot |
| Email    | SMTP host, port, user, **App Password** (not normal password) |

### Gmail App Password setup
1. myaccount.google.com → Security → 2-Step Verification → App passwords
2. Create one named "SMS Forwarder"
3. Paste the 16-char code as the password in the app

---

## Battery optimisation (important!)
The app prompts you to disable battery optimisation on first launch.
Accept it, or SMS forwarding will stop when the phone is idle.

Manual path: Settings → Apps → SMS Forwarder → Battery → Unrestricted
