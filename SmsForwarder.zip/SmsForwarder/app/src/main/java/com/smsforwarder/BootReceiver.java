package com.smsforwarder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.i("SmsForwarder", "Boot complete – SMS forwarding active");
            // SmsReceiver is manifest-declared so it's already listening.
            // This receiver confirms the app survived a reboot.
        }
    }
}
