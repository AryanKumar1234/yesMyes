package com.smsforwarder;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int PERM_REQ = 1;

    // SMS section
    private Switch swSms;
    private EditText etNumber;

    // Telegram section
    private Switch swTelegram;
    private EditText etToken, etChatId;

    // Email section
    private Switch swEmail;
    private EditText etSmtpHost, etSmtpPort, etSmtpUser, etSmtpPass, etEmailTo;

    private TextView tvStatus;
    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = new Prefs(this);

        bindViews();
        loadPrefs();
        wireListeners();
        requestSmsPerms();
        requestBatteryExemption();
    }

    // ──────────────────────────────────────────────────────────────────────────
    private void bindViews() {
        swSms        = findViewById(R.id.sw_sms);
        etNumber     = findViewById(R.id.et_number);
        swTelegram   = findViewById(R.id.sw_telegram);
        etToken      = findViewById(R.id.et_token);
        etChatId     = findViewById(R.id.et_chat_id);
        swEmail      = findViewById(R.id.sw_email);
        etSmtpHost   = findViewById(R.id.et_smtp_host);
        etSmtpPort   = findViewById(R.id.et_smtp_port);
        etSmtpUser   = findViewById(R.id.et_smtp_user);
        etSmtpPass   = findViewById(R.id.et_smtp_pass);
        etEmailTo    = findViewById(R.id.et_email_to);
        tvStatus     = findViewById(R.id.tv_status);

        findViewById(R.id.btn_save).setOnClickListener(v -> savePrefs());
        findViewById(R.id.btn_test).setOnClickListener(v -> runTest());
    }

    private void loadPrefs() {
        swSms.setChecked(prefs.isSmsEnabled());
        etNumber.setText(prefs.getTargetNumber());

        swTelegram.setChecked(prefs.isTelegramEnabled());
        etToken.setText(prefs.getBotToken());
        etChatId.setText(prefs.getChatId());

        swEmail.setChecked(prefs.isEmailEnabled());
        etSmtpHost.setText(prefs.getSmtpHost());
        etSmtpPort.setText(prefs.getSmtpPort());
        etSmtpUser.setText(prefs.getSmtpUser());
        etSmtpPass.setText(prefs.getSmtpPass());
        etEmailTo.setText(prefs.getEmailTo());

        refreshEnabled();
        updateStatus();
    }

    private void wireListeners() {
        swSms.setOnCheckedChangeListener((b, c)      -> refreshEnabled());
        swTelegram.setOnCheckedChangeListener((b, c) -> refreshEnabled());
        swEmail.setOnCheckedChangeListener((b, c)    -> refreshEnabled());
    }

    private void savePrefs() {
        prefs.setSmsEnabled(swSms.isChecked());
        prefs.setTargetNumber(etNumber.getText().toString().trim());

        prefs.setTelegramEnabled(swTelegram.isChecked());
        prefs.setBotToken(etToken.getText().toString().trim());
        prefs.setChatId(etChatId.getText().toString().trim());

        prefs.setEmailEnabled(swEmail.isChecked());
        prefs.setSmtpHost(etSmtpHost.getText().toString().trim());
        prefs.setSmtpPort(etSmtpPort.getText().toString().trim());
        prefs.setSmtpUser(etSmtpUser.getText().toString().trim());
        prefs.setSmtpPass(etSmtpPass.getText().toString().trim());
        prefs.setEmailTo(etEmailTo.getText().toString().trim());

        Toast.makeText(this, "✅ Settings saved", Toast.LENGTH_SHORT).show();
        updateStatus();
    }

    private void runTest() {
        savePrefs();
        tvStatus.setText("⏳ Sending test…");
        new Thread(() -> {
            ForwardingHelper.testForward(this);
            runOnUiThread(() -> tvStatus.setText("✅ Test sent! Check each channel."));
        }).start();
    }

    private void refreshEnabled() {
        etNumber.setEnabled(swSms.isChecked());

        etToken.setEnabled(swTelegram.isChecked());
        etChatId.setEnabled(swTelegram.isChecked());

        etSmtpHost.setEnabled(swEmail.isChecked());
        etSmtpPort.setEnabled(swEmail.isChecked());
        etSmtpUser.setEnabled(swEmail.isChecked());
        etSmtpPass.setEnabled(swEmail.isChecked());
        etEmailTo.setEnabled(swEmail.isChecked());
    }

    private void updateStatus() {
        int channels = 0;
        if (prefs.isSmsEnabled())      channels++;
        if (prefs.isTelegramEnabled()) channels++;
        if (prefs.isEmailEnabled())    channels++;
        tvStatus.setText(channels == 0
                ? "⚠️  No channels enabled"
                : "✅  Active – forwarding to " + channels + " channel(s)");
    }

    // ──────────────────────────────────────────────────────────────────────────
    private void requestSmsPerms() {
        String[] needed = {
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS
        };
        boolean any = false;
        for (String p : needed) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                any = true; break;
            }
        }
        if (any) ActivityCompat.requestPermissions(this, needed, PERM_REQ);
    }

    private void requestBatteryExemption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == PERM_REQ) {
            for (int r : results) {
                if (r != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "⚠️ SMS permission denied – forwarding won't work",
                            Toast.LENGTH_LONG).show();
                    return;
                }
            }
            Toast.makeText(this, "✅ All permissions granted", Toast.LENGTH_SHORT).show();
        }
    }
}
