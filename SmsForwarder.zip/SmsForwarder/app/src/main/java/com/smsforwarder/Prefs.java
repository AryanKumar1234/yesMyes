package com.smsforwarder;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private static final String PREF_NAME = "sms_forwarder";
    private final SharedPreferences p;

    public Prefs(Context ctx) {
        p = ctx.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    // ── SMS to Number ──────────────────────────────────────────────────────────
    public boolean isSmsEnabled()         { return p.getBoolean("sms_on", false); }
    public void setSmsEnabled(boolean v)  { p.edit().putBoolean("sms_on", v).apply(); }
    public String getTargetNumber()       { return p.getString("target_num", ""); }
    public void setTargetNumber(String v) { p.edit().putString("target_num", v).apply(); }

    // ── Telegram ───────────────────────────────────────────────────────────────
    public boolean isTelegramEnabled()        { return p.getBoolean("tg_on", false); }
    public void setTelegramEnabled(boolean v) { p.edit().putBoolean("tg_on", v).apply(); }
    public String getBotToken()               { return p.getString("tg_token", ""); }
    public void setBotToken(String v)         { p.edit().putString("tg_token", v).apply(); }
    public String getChatId()                 { return p.getString("tg_chat", ""); }
    public void setChatId(String v)           { p.edit().putString("tg_chat", v).apply(); }

    // ── Email ──────────────────────────────────────────────────────────────────
    public boolean isEmailEnabled()        { return p.getBoolean("em_on", false); }
    public void setEmailEnabled(boolean v) { p.edit().putBoolean("em_on", v).apply(); }
    public String getSmtpHost()            { return p.getString("em_host", "smtp.gmail.com"); }
    public void setSmtpHost(String v)      { p.edit().putString("em_host", v).apply(); }
    public String getSmtpPort()            { return p.getString("em_port", "465"); }
    public void setSmtpPort(String v)      { p.edit().putString("em_port", v).apply(); }
    public String getSmtpUser()            { return p.getString("em_user", ""); }
    public void setSmtpUser(String v)      { p.edit().putString("em_user", v).apply(); }
    public String getSmtpPass()            { return p.getString("em_pass", ""); }
    public void setSmtpPass(String v)      { p.edit().putString("em_pass", v).apply(); }
    public String getEmailTo()             { return p.getString("em_to", ""); }
    public void setEmailTo(String v)       { p.edit().putString("em_to", v).apply(); }
}
