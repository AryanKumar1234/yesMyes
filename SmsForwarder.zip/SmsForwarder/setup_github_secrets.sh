#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
#  SMS Forwarder – GitHub Secrets Setup Helper
#  Run this locally AFTER running ./generate_keystore.sh
#  It prints the exact values to paste into GitHub Secrets.
# ─────────────────────────────────────────────────────────────────────────────

KEYSTORE="smsforwarder-release.jks"

if [ ! -f "$KEYSTORE" ]; then
    echo "❌  No keystore found. Run ./generate_keystore.sh first."
    exit 1
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   GitHub Secrets Setup                                        ║"
echo "║   Repo → Settings → Secrets and variables → Actions          ║"
echo "║   Click 'New repository secret' for each one below           ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

echo "━━━  Secret 1 of 4  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Name:   KEYSTORE_BASE64"
echo "Value:  (copy the entire line below)"
echo ""
base64 -w 0 "$KEYSTORE"
echo ""

echo ""
echo "━━━  Secret 2 of 4  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Name:   KEYSTORE_PASSWORD"
echo "Value:  your keystore password (what you typed in generate_keystore.sh)"
echo ""

echo "━━━  Secret 3 of 4  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Name:   KEY_ALIAS"
echo "Value:  smsforwarder"
echo ""

echo "━━━  Secret 4 of 4  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Name:   KEY_PASSWORD"
echo "Value:  your key password (same as keystore password)"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "After adding all 4 secrets:"
echo "  • Push a commit → workflow runs automatically"
echo "  • Or: Actions tab → Build & Sign APK → Run workflow"
echo "  • Download APK: Actions → latest run → Artifacts → sms-forwarder-release"
echo ""
