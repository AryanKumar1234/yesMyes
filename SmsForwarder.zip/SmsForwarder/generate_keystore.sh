#!/bin/bash
# ─────────────────────────────────────────────────────────────────
#  SMS Forwarder – Release Keystore Generator
#  Run this ONCE.  Back up smsforwarder-release.jks somewhere safe.
#  Losing the keystore = you can NEVER update the app again.
# ─────────────────────────────────────────────────────────────────

KEYSTORE="smsforwarder-release.jks"
ALIAS="smsforwarder"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   SMS Forwarder – Keystore Generator          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

if [ -f "$KEYSTORE" ]; then
    echo "⚠️  Keystore already exists: $KEYSTORE"
    echo "    Delete it first if you really want to regenerate."
    echo "    WARNING: regenerating breaks updates for existing installs!"
    exit 0
fi

read -s -p "Enter keystore password (min 6 chars): " PASS; echo
read -s -p "Confirm password: "                       PASS2; echo

if [ "$PASS" != "$PASS2" ]; then
    echo "❌  Passwords do not match. Aborting."
    exit 1
fi

keytool -genkeypair \
    -keystore  "$KEYSTORE" \
    -alias     "$ALIAS"    \
    -keyalg    RSA         \
    -keysize   2048        \
    -validity  10000       \
    -storepass "$PASS"     \
    -keypass   "$PASS"     \
    -dname     "CN=SmsForwarder,OU=Dev,O=Personal,L=City,ST=State,C=US" \
    -v

if [ $? -ne 0 ]; then
    echo "❌  keytool failed. Make sure JDK is installed (java -version)."
    exit 1
fi

# Write keystore.properties automatically
cat > keystore.properties << EOF
# DO NOT COMMIT THIS FILE
storeFile=../$KEYSTORE
storePassword=$PASS
keyAlias=$ALIAS
keyPassword=$PASS
EOF

echo ""
echo "✅  Keystore:           $KEYSTORE"
echo "✅  keystore.properties updated"
echo ""
echo "Next steps:"
echo "  1.  Open project in Android Studio  →  Build → Generate Signed APK"
echo "      OR  run:  ./gradlew assembleRelease"
echo "  2.  APK lands in:  app/build/outputs/apk/release/app-release.apk"
echo "  3.  Install:       adb install -r app-release.apk"
echo ""
echo "🔐  Back up $KEYSTORE and keystore.properties to a safe place!"
