package com.onion.yesmyes

/**
 * Recognizes OTP/verification-code SMS and pulls out (appName, otpCode) so
 * they can be forwarded in the short "AppName: <otp>" format instead of the
 * full message. Not an OTP -> returns null and the caller forwards the
 * message normally.
 */
object OtpDetector {

    data class OtpInfo(val appName: String, val otp: String)

    private val OTP_CODE_REGEX = Regex("\\b\\d{4,8}\\b")
    private val OTP_WORD_REGEX = Regex("\\botp\\b", RegexOption.IGNORE_CASE)
    private val OTP_KEYWORDS = listOf(
        "one time password", "verification code", "security code",
        "passcode", "auth code", "authentication code", "login code"
    )

    fun detect(sender: String, body: String): OtpInfo? {
        val lower = body.lowercase()
        val looksLikeOtp = OTP_WORD_REGEX.containsMatchIn(body) ||
            OTP_KEYWORDS.any { lower.contains(it) }
        if (!looksLikeOtp) return null

        val otpMatch = OTP_CODE_REGEX.find(body) ?: return null

        return OtpInfo(appName = extractAppName(sender, body), otp = otpMatch.value)
    }

    private fun extractAppName(sender: String, body: String): String {
        // Template "WoahTeaPea: your code is 123456" -> text before the first colon.
        val colonIdx = body.indexOf(':')
        if (colonIdx in 1..24) {
            val prefix = body.substring(0, colonIdx).trim()
            if (prefix.isNotBlank() && prefix.split(" ").size <= 3) return prefix
        }

        // Business SMS senders are usually an alphanumeric ID (e.g. "WoahTeaPea",
        // "AX-HDFCBK"), not a phone number — that ID is usually the service name.
        if (sender.isNotBlank() && !sender.all { it.isDigit() || it == '+' }) {
            return sender
        }

        return "SMS"
    }
}
