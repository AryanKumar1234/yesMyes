package com.onion.yesmyes

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Runs off the main thread, outside the BroadcastReceiver's short time
 * budget, with WorkManager retry-on-failure. Encrypts the message once,
 * then fans it out to every enabled channel independently so one channel
 * failing (e.g. no network connectivity) doesn't block the others.
 */
class ForwardWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_SENDER = "sender"
        const val KEY_BODY = "body"
        const val KEY_TELEGRAM_ERROR = "telegram_error"
        const val KEY_SMS_ERROR = "sms_error"
        private const val TAG = "ForwardWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val sender = inputData.getString(KEY_SENDER) ?: "unknown"
        val body = inputData.getString(KEY_BODY) ?: return@withContext Result.failure()

        val cipherKey = Prefs.cipherKey(applicationContext)
        val isOtp = OtpDetector.detect(sender, body) != null

        // OTP messages go out as-is, in plain text (no cipher) — only the literal
        // word "OTP" is swapped for "WoahTeaPea". Everything else still goes
        // through the normal substitution cipher, same as before.
        val transformedBody = if (isOtp) {
            body.replace(Regex("\\botp\\b", RegexOption.IGNORE_CASE), "WoahTeaPea")
        } else {
            CipherUtil.encrypt(body, cipherKey)
        }
        val subject = "SMS from $sender"
        val outgoingText = "$subject:\n$transformedBody"

        var telegramError: String? = null
        var smsError: String? = null

        if (Prefs.telegramEnabled(applicationContext)) {
            try {
                TelegramForwarder.send(
                    Prefs.telegramToken(applicationContext),
                    Prefs.telegramChatId(applicationContext),
                    outgoingText
                )
            } catch (e: Exception) {
                Log.e(TAG, "Telegram forward failed", e)
                telegramError = e.message ?: e.toString()
            }
        }

        val paused = Prefs.forwardingPaused(applicationContext) // set remotely via Telegram /stop

        if (Prefs.smsEnabled(applicationContext) && !paused) {
            try {
                val toNumber = Prefs.forwardNumber(applicationContext)
                if (toNumber.isNotBlank()) {
                    SmsForwarder.send(applicationContext, toNumber, outgoingText)
                }
            } catch (e: Exception) {
                Log.e(TAG, "SMS forward failed", e)
                smsError = e.message ?: e.toString()
            }
        }

        // Not retrying the whole job on a single channel's failure: a retry re-runs
        // every channel, including ones that already succeeded (e.g. Telegram),
        // which is what caused duplicate messages. A failed channel's error is
        // surfaced in outputData below instead of being retried.
        val outputData = workDataOf(
            KEY_TELEGRAM_ERROR to telegramError,
            KEY_SMS_ERROR to smsError
        )
        Result.success(outputData)
    }
}
