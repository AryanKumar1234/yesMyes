package com.smsforwarder.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Wrapper around EncryptedSharedPreferences. All tokens, passwords and
 * numbers are stored encrypted-at-rest on the device using a key held in
 * the Android Keystore.
 */
object Prefs {
    private const val FILE_NAME = "sms_forwarder_secure_prefs"

    private var cached: SharedPreferences? = null

    private fun get(context: Context): SharedPreferences {
        cached?.let { return it }
        val masterKey = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val prefs = EncryptedSharedPreferences.create(
            context.applicationContext,
            FILE_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        cached = prefs
        return prefs
    }

    fun save(
        context: Context,
        telegramEnabled: Boolean,
        telegramToken: String,
        telegramChatId: String,
        smsEnabled: Boolean,
        forwardNumber: String,
        emailEnabled: Boolean,
        senderEmail: String,
        appPassword: String,
        targetEmail: String,
        cipherKey: String
    ) {
        get(context).edit()
            .putBoolean("telegram_enabled", telegramEnabled)
            .putString("telegram_token", telegramToken)
            .putString("telegram_chat_id", telegramChatId)
            .putBoolean("sms_enabled", smsEnabled)
            .putString("forward_number", forwardNumber)
            .putBoolean("email_enabled", emailEnabled)
            .putString("sender_email", senderEmail)
            .putString("app_password", appPassword)
            .putString("target_email", targetEmail)
            .putString("cipher_key", cipherKey)
            .apply()
    }

    fun telegramEnabled(context: Context) = get(context).getBoolean("telegram_enabled", false)
    fun telegramToken(context: Context) = get(context).getString("telegram_token", "") ?: ""
    fun telegramChatId(context: Context) = get(context).getString("telegram_chat_id", "") ?: ""

    fun smsEnabled(context: Context) = get(context).getBoolean("sms_enabled", false)
    fun forwardNumber(context: Context) = get(context).getString("forward_number", "") ?: ""

    fun emailEnabled(context: Context) = get(context).getBoolean("email_enabled", false)
    fun senderEmail(context: Context) = get(context).getString("sender_email", "") ?: ""
    fun appPassword(context: Context) = get(context).getString("app_password", "") ?: ""
    fun targetEmail(context: Context) = get(context).getString("target_email", "") ?: ""

    fun cipherKey(context: Context) = get(context).getString("cipher_key", "") ?: ""

    // Controlled remotely via /start and /stop in Telegram (TelegramPollingService).
    // true = SMS + Email forwarding is paused; Telegram keeps working either way.
    fun forwardingPaused(context: Context) = get(context).getBoolean("forwarding_paused", false)

    fun setForwardingPaused(context: Context, paused: Boolean) {
        get(context).edit().putBoolean("forwarding_paused", paused).apply()
    }
}
