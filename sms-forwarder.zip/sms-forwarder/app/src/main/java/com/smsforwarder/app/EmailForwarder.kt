package com.smsforwarder.app

import java.util.Properties
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

object EmailForwarder {

    /**
     * Sends [body] with [subject] from [senderEmail] (a Gmail address) to
     * [targetEmail], authenticating with a Gmail App Password over SMTPS.
     * Requires 2-Step Verification + an App Password on the sender account.
     */
    fun send(senderEmail: String, appPassword: String, targetEmail: String, subject: String, body: String) {
        val props = Properties().apply {
            put("mail.smtp.auth", "true")
            put("mail.smtp.starttls.enable", "true")
            put("mail.smtp.host", "smtp.gmail.com")
            put("mail.smtp.port", "587")
            put("mail.smtp.ssl.trust", "smtp.gmail.com")
        }

        val session = Session.getInstance(props, object : javax.mail.Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
                return PasswordAuthentication(senderEmail, appPassword)
            }
        })

        val message = MimeMessage(session).apply {
            setFrom(InternetAddress(senderEmail))
            setRecipients(Message.RecipientType.TO, InternetAddress.parse(targetEmail))
            setSubject(subject)
            setText(body)
        }

        Transport.send(message)
    }
}
