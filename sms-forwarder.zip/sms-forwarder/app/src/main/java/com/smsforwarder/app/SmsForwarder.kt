package com.smsforwarder.app

import android.content.Context
import android.telephony.SmsManager

object SmsForwarder {

    /** Forwards [text] to [toNumber] as one or more SMS parts. */
    @Suppress("DEPRECATION")
    fun send(context: Context, toNumber: String, text: String) {
        val smsManager: SmsManager =
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                context.getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }

        val parts = smsManager.divideMessage(text)
        smsManager.sendMultipartTextMessage(toNumber, null, parts, null, null)
    }
}
