package com.smsforwarder.app

/**
 * Simple substitution cipher.
 *
 * The key is a 36-character permutation of "abcdefghijklmnopqrstuvwxyz0123456789".
 * Each letter/digit of the plaintext is replaced by the character at the same
 * position in the key's alphabet (ALPHABET[i] -> key[i]). Case of letters is
 * preserved. Anything outside a-z0-9 (spaces, punctuation, symbols) passes
 * through unchanged, so message structure/OTP formatting stays readable
 * after decryption.
 *
 * This is NOT strong cryptography (a substitution cipher is breakable by
 * frequency analysis). It only obscures forwarded content from someone
 * glancing at Telegram/SMS; treat the cipher key itself as a secret,
 * and consider swapping this for AES if you need real confidentiality.
 */
object CipherUtil {

    private const val ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789"

    /** Returns null if the key isn't a valid 36-char permutation of ALPHABET. */
    fun validateKey(key: String): Boolean {
        if (key.length != ALPHABET.length) return false
        val sortedKey = key.lowercase().toCharArray().sorted()
        val sortedAlphabet = ALPHABET.toCharArray().sorted()
        return sortedKey == sortedAlphabet
    }

    fun encrypt(text: String, key: String): String {
        if (key.isBlank()) return text
        if (!validateKey(key)) return text // fail safe: don't mangle text with a bad key
        return transform(text, ALPHABET, key.lowercase())
    }

    fun decrypt(text: String, key: String): String {
        if (key.isBlank()) return text
        if (!validateKey(key)) return text
        return transform(text, key.lowercase(), ALPHABET)
    }

    private fun transform(text: String, from: String, to: String): String {
        val sb = StringBuilder(text.length)
        for (c in text) {
            val lower = c.lowercaseChar()
            val idx = from.indexOf(lower)
            if (idx == -1) {
                sb.append(c)
            } else {
                val mapped = to[idx]
                sb.append(if (c.isUpperCase()) mapped.uppercaseChar() else mapped)
            }
        }
        return sb.toString()
    }
}
