package com.smsforwarder.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.smsforwarder.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        Toast.makeText(
            this,
            if (allGranted) "Permissions granted" else "Some permissions were denied — forwarding won't work without them",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadSettings()

        binding.btnGrantPermissions.setOnClickListener { requestPermissions() }
        binding.btnSave.setOnClickListener { saveSettings() }
        binding.btnTest.setOnClickListener { sendTestMessage() }
    }

    private fun requestPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            Toast.makeText(this, "Already granted", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSettings() {
        binding.cbTelegram.isChecked = Prefs.telegramEnabled(this)
        binding.etTelegramToken.setText(Prefs.telegramToken(this))
        binding.etTelegramChatId.setText(Prefs.telegramChatId(this))

        binding.cbSms.isChecked = Prefs.smsEnabled(this)
        binding.etForwardNumber.setText(Prefs.forwardNumber(this))

        binding.cbEmail.isChecked = Prefs.emailEnabled(this)
        binding.etSenderEmail.setText(Prefs.senderEmail(this))
        binding.etAppPassword.setText(Prefs.appPassword(this))
        binding.etTargetEmail.setText(Prefs.targetEmail(this))

        binding.etCipherKey.setText(Prefs.cipherKey(this))
    }

    private fun saveSettings() {
        val cipherKey = binding.etCipherKey.text.toString().trim()
        if (cipherKey.isNotBlank() && !CipherUtil.validateKey(cipherKey)) {
            binding.tvStatus.text =
                "Cipher key must be exactly 36 characters: a permutation of a-z0-9. Not saved."
            return
        }

        Prefs.save(
            context = this,
            telegramEnabled = binding.cbTelegram.isChecked,
            telegramToken = binding.etTelegramToken.text.toString().trim(),
            telegramChatId = binding.etTelegramChatId.text.toString().trim(),
            smsEnabled = binding.cbSms.isChecked,
            forwardNumber = binding.etForwardNumber.text.toString().trim(),
            emailEnabled = binding.cbEmail.isChecked,
            senderEmail = binding.etSenderEmail.text.toString().trim(),
            appPassword = binding.etAppPassword.text.toString().trim(),
            targetEmail = binding.etTargetEmail.text.toString().trim(),
            cipherKey = cipherKey
        )
        binding.tvStatus.text = "Saved."
    }

    private fun sendTestMessage() {
        saveSettings()
        val request = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(
                workDataOf(
                    ForwardWorker.KEY_SENDER to "TEST",
                    ForwardWorker.KEY_BODY to "This is a test message, OTP 123456"
                )
            )
            .build()
        WorkManager.getInstance(applicationContext).enqueue(request)
        binding.tvStatus.text = "Test message queued — check your channels."
    }
}
