package com.smsforwarder.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Long-polls Telegram's getUpdates so the bot can react to commands sent
 * from your phone, without needing a public webhook/server.
 *
 * /stop  -> pauses SMS forwarding. Telegram forwarding stays on so
 *           you can still see incoming messages and send /start to resume.
 * /start -> resumes SMS forwarding.
 *
 * Only messages from the chat ID configured in Settings are accepted —
 * anyone else messaging the bot is ignored.
 */
class TelegramPollingService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        if (job?.isActive != true) {
            job = scope.launch { pollLoop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }

    private suspend fun pollLoop() {
        var offset = 0L
        while (scope.isActive) {
            val token = Prefs.telegramToken(applicationContext)
            val chatId = Prefs.telegramChatId(applicationContext)
            if (token.isBlank() || chatId.isBlank()) {
                delay(10_000)
                continue
            }
            try {
                val updates = getUpdates(token, offset)
                for (update in updates) {
                    offset = maxOf(offset, update.getLong("update_id") + 1)
                    handleUpdate(update, token, chatId)
                }
            } catch (e: Exception) {
                // Network hiccup / timeout from long-polling — just retry.
                delay(5000)
            }
        }
    }

    /** Long-polls for up to 25s so this doesn't spam Telegram's API. */
    private fun getUpdates(token: String, offset: Long): List<JSONObject> {
        val url = URL("https://api.telegram.org/bot$token/getUpdates?timeout=25&offset=$offset")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 35_000
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        val result = JSONObject(text).optJSONArray("result") ?: return emptyList()
        return (0 until result.length()).map { result.getJSONObject(it) }
    }

    private fun handleUpdate(update: JSONObject, token: String, configuredChatId: String) {
        val message = update.optJSONObject("message") ?: return
        val text = message.optString("text", "").trim().lowercase()
        val fromChatId = message.optJSONObject("chat")?.optLong("id")?.toString() ?: return

        if (fromChatId != configuredChatId.trim()) return // ignore anyone but you

        when (text) {
            "/start" -> {
                Prefs.setForwardingPaused(applicationContext, false)
                TelegramForwarder.send(token, configuredChatId, "Forwarding resumed — SMS is back on.")
            }
            "/stop" -> {
                Prefs.setForwardingPaused(applicationContext, true)
                TelegramForwarder.send(token, configuredChatId, "Forwarding paused — SMS is off until you send /start. (Telegram stays on.)")
            }
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "telegram_listener"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager.getNotificationChannel(channelId) == null) {
                manager.createNotificationChannel(
                    NotificationChannel(channelId, "Telegram listener", NotificationManager.IMPORTANCE_MIN)
                )
            }
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("SMS Forwarder")
            .setContentText("Listening for /start and /stop on Telegram")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 42
    }
}
