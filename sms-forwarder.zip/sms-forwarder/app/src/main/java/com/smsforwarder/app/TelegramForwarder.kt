package com.smsforwarder.app

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.net.ssl.HttpsURLConnection

object TelegramForwarder {

    /** Sends [text] to the configured chat via the Telegram Bot API. Throws on failure. */
    fun send(botToken: String, chatId: String, text: String) {
        val urlStr = "https://api.telegram.org/bot$botToken/sendMessage"
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpsURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            conn.connectTimeout = 15000
            conn.readTimeout = 15000

            val body = "chat_id=${URLEncoder.encode(chatId, "UTF-8")}" +
                "&text=${URLEncoder.encode(text, "UTF-8")}"

            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_OK) {
                val err = conn.errorStream?.bufferedReader()?.readText() ?: "no body"
                throw RuntimeException("Telegram API returned $code: $err")
            }
        } finally {
            conn.disconnect()
        }
    }
}
