package com.smsforwarder.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        // Multi-part SMS arrive as separate PDUs with the same sender; stitch them back together.
        val sender = messages[0].originatingAddress ?: "unknown"
        val fullBody = messages.joinToString(separator = "") { it.messageBody ?: "" }

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = OneTimeWorkRequestBuilder<ForwardWorker>()
            .setInputData(
                workDataOf(
                    ForwardWorker.KEY_SENDER to sender,
                    ForwardWorker.KEY_BODY to fullBody
                )
            )
            .setConstraints(constraints)
            .build()

        // SMS forwarding is network-dependent only for Telegram/email; SMS-to-SMS
        // doesn't need NetworkType.CONNECTED, but requiring it keeps this simple and
        // still lets WorkManager run it the moment connectivity is back.
        WorkManager.getInstance(context.applicationContext)
            .enqueueUniqueWork(
                "forward_${System.currentTimeMillis()}",
                ExistingWorkPolicy.APPEND_OR_REPLACE,
                request
            )
    }
}
