package com.smsforwarder.app

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Runs off the main thread, outside the BroadcastReceiver's short time
 * budget, with WorkManager retry-on-failure. Encrypts the message once,
 * then fans it out to every enabled channel independently so one channel
 * failing (e.g. no SMTP connectivity) doesn't block the others.
 */
class ForwardWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_SENDER = "sender"
        const val KEY_BODY = "body"
        private const val TAG = "ForwardWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val sender = inputData.getString(KEY_SENDER) ?: "unknown"
        val body = inputData.getString(KEY_BODY) ?: return@withContext Result.failure()

        val cipherKey = Prefs.cipherKey(applicationContext)
        val payload = CipherUtil.encrypt(body, cipherKey)
        val header = "SMS from $sender"

        var anyFailure = false

        if (Prefs.telegramEnabled(applicationContext)) {
            try {
                TelegramForwarder.send(
                    Prefs.telegramToken(applicationContext),
                    Prefs.telegramChatId(applicationContext),
                    "$header:\n$payload"
                )
            } catch (e: Exception) {
                Log.e(TAG, "Telegram forward failed", e)
                anyFailure = true
            }
        }

        if (Prefs.smsEnabled(applicationContext)) {
            try {
                val toNumber = Prefs.forwardNumber(applicationContext)
                if (toNumber.isNotBlank()) {
                    SmsForwarder.send(applicationContext, toNumber, "$header: $payload")
                }
            } catch (e: Exception) {
                Log.e(TAG, "SMS forward failed", e)
                anyFailure = true
            }
        }

        if (Prefs.emailEnabled(applicationContext)) {
            try {
                EmailForwarder.send(
                    senderEmail = Prefs.senderEmail(applicationContext),
                    appPassword = Prefs.appPassword(applicationContext),
                    targetEmail = Prefs.targetEmail(applicationContext),
                    subject = header,
                    body = payload
                )
            } catch (e: Exception) {
                Log.e(TAG, "Email forward failed", e)
                anyFailure = true
            }
        }

        if (anyFailure && runAttemptCount < 3) Result.retry() else Result.success()
    }
}
