package com.smsforwarder.app

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Runs off the main thread, outside the BroadcastReceiver's short time
 * budget, with WorkManager retry-on-failure. Encrypts the message once,
 * then fans it out to every enabled channel independently so one channel
 * failing (e.g. no SMTP connectivity) doesn't block the others.
 */
class ForwardWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    companion object {
        const val KEY_SENDER = "sender"
        const val KEY_BODY = "body"
        private const val TAG = "ForwardWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val sender = inputData.getString(KEY_SENDER) ?: "unknown"
        val body = inputData.getString(KEY_BODY) ?: return@withContext Result.failure()

        val cipherKey = Prefs.cipherKey(applicationContext)
        val otpInfo = OtpDetector.detect(sender, body)

        // OTP messages forward as the short "AppName: <otp>" template; everything
        // else keeps the full "SMS from <sender>: <message>" format.
        val subject: String
        val outgoingText: String
        if (otpInfo != null) {
            val otpEncryptOn = Prefs.otpEncryptEnabled(applicationContext)
            val otpOut = if (otpEncryptOn) CipherUtil.encrypt(otpInfo.otp, cipherKey) else otpInfo.otp
            subject = otpInfo.appName
            outgoingText = "${otpInfo.appName}: $otpOut"
        } else {
            val payload = CipherUtil.encrypt(body, cipherKey)
            subject = "SMS from $sender"
            outgoingText = "$subject:\n$payload"
        }

        var anyFailure = false

        if (Prefs.telegramEnabled(applicationContext)) {
            try {
                TelegramForwarder.send(
                    Prefs.telegramToken(applicationContext),
                    Prefs.telegramChatId(applicationContext),
                    outgoingText
                )
            } catch (e: Exception) {
                Log.e(TAG, "Telegram forward failed", e)
                anyFailure = true
            }
        }

        val paused = Prefs.forwardingPaused(applicationContext) // set remotely via Telegram /stop

        if (Prefs.smsEnabled(applicationContext) && !paused) {
            try {
                val toNumber = Prefs.forwardNumber(applicationContext)
                if (toNumber.isNotBlank()) {
                    SmsForwarder.send(applicationContext, toNumber, outgoingText)
                }
            } catch (e: Exception) {
                Log.e(TAG, "SMS forward failed", e)
                anyFailure = true
            }
        }

        if (Prefs.emailEnabled(applicationContext) && !paused) {
            try {
                EmailForwarder.send(
                    senderEmail = Prefs.senderEmail(applicationContext),
                    appPassword = Prefs.appPassword(applicationContext),
                    targetEmail = Prefs.targetEmail(applicationContext),
                    subject = subject,
                    body = outgoingText
                )
            } catch (e: Exception) {
                Log.e(TAG, "Email forward failed", e)
                anyFailure = true
            }
        }

        if (anyFailure && runAttemptCount < 3) Result.retry() else Result.success()
    }
}
