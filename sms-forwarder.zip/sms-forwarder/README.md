# SMS Forwarder

Android app (Kotlin) that watches for incoming SMS and forwards each message to:

- **Telegram** — via a bot you create with [@BotFather](https://t.me/BotFather)
- **Another phone number** — via a normal SMS send (carrier rates apply)
- **Email** — via Gmail SMTP using an [App Password](https://myaccount.google.com/apppasswords)

Before forwarding, the message body is run through a configurable **substitution
cipher** (see "Encryption" below) so OTPs aren't sent in the clear to any channel.

Android only — iOS does not allow third-party apps to read incoming SMS.

## Setup

1. Install the APK (see "Getting a build" below) and open the app.
2. Tap **Grant SMS Permissions** and allow SMS + notifications.
3. Fill in whichever channels you want enabled, and tick their checkboxes:
   - **Telegram**: message your bot once first (Telegram requires that before
     it will let the bot message you), then get your numeric chat ID from
     `https://api.telegram.org/bot<TOKEN>/getUpdates`.
   - **SMS forward**: destination number in `+countrycode...` format.
   - **Email**: a Gmail address with 2-Step Verification on, its 16-character
     App Password, and the destination inbox.
4. Enter a **cipher key** (see below) or leave blank to forward plaintext.
5. Tap **Save Settings**, then **Send Test Message** to confirm all three
   channels work before relying on it.
6. On the device, exempt the app from battery optimization (Settings → Apps →
   SMS Forwarder → Battery → Unrestricted) so Android doesn't kill it in the
   background.

## OTP handling

Messages that look like an OTP (containing "OTP" or phrases like "verification
code", plus a 4-8 digit number) are detected automatically and forwarded in a
short form: `AppName: <encrypted otp>`, where the app name is taken from the
`AppName: ...` prefix in the SMS body if present, otherwise from the SMS
sender ID. Everything else still forwards as `SMS from <sender>: <message>`.

OTP encryption is on by default and can't be silently turned off — unchecking
**Encrypt OTP codes** in Settings shows a confirmation dialog warning that
plaintext OTP forwarding can get an account flagged or blocked, with "Keep
encrypted" as the default button.

## Encryption

`CipherUtil.kt` implements a straightforward substitution cipher: the key is
a 36-character permutation of `abcdefghijklmnopqrstuvwxyz0123456789`. Each
letter or digit in the message is swapped one-for-one per the key; spaces and
punctuation pass through unchanged. The same key decrypts on the other end —
write a matching small decrypt script/page wherever you're reading the
forwarded messages.

**Be aware**: a substitution cipher is not strong cryptography — it's
breakable by frequency analysis given enough messages. It mainly stops a
shoulder-surfer or a compromised bot/inbox from reading an OTP at a glance.
If you need real confidentiality, replace `CipherUtil` with AES-GCM using a
key you control (the rest of the app doesn't care how encrypt/decrypt are
implemented).

## Getting a build

Every push to `main` triggers `.github/workflows/build.yml`, which builds a
debug APK and attaches it to a new GitHub Release in this repo. Debug-signed
APKs are fine to sideload on your own device but aren't suitable for Play
Store distribution — that needs a release keystore, which isn't set up here.

To build locally instead: open the project in Android Studio, or run
`gradle assembleDebug` with Android SDK + JDK 17 installed.

## Permissions note

Google Play restricts apps that request SMS permissions unless SMS handling
is the app's core purpose and it goes through Play's SMS/Call Log policy
review. This app is intended for personal sideloading, not Play Store
distribution.

## Security notes

- All tokens, passwords and the cipher key are stored in
  `EncryptedSharedPreferences`, backed by the Android Keystore.
- Telegram and email are not end-to-end encrypted transports — the
  substitution cipher is your only protection on the wire/in those inboxes.
- Use this only with your own phone number and accounts.
