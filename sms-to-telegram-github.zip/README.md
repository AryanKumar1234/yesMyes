# SMS to Telegram — build it from your phone (no computer needed)

This repo builds itself automatically using GitHub Actions. You just need
to get these files into a GitHub repo, and GitHub's servers compile the
APK for you.

## Step 1 — Create a GitHub account
Go to github.com in your phone's browser and sign up (free).

## Step 2 — Create a new repository
- Tap the "+" → "New repository"
- Name it anything, e.g. `sms-to-telegram`
- Choose Private or Public (either works — no secrets are stored in this code)
- Tap "Create repository"

## Step 3 — Upload these files
On the new repo's page:
- Tap "Add file" → "Upload files"
- Unzip this archive with your phone's file manager app first (most have
  a built-in "Extract"/"Unzip" option — tap the .zip and look for it)
- In the uploader, choose to upload the **extracted folder** so all the
  subfolders (`app/src/main/java/...` etc.) come along. If your browser's
  file picker only lets you select individual files instead of a folder,
  see the "Fallback: Termux" method below — it's more reliable for this
  part.
- Commit directly to the `main` branch

## Step 4 — Let it build
- Tap the "Actions" tab in your repo — you'll see a build running
  automatically (takes 2–4 minutes)
- When it's green/done, go to the "Releases" section on the repo's main
  page (right-hand sidebar on desktop view, or scroll down on mobile)
- Tap the newest release, download **app-debug.apk** directly to your phone

## Step 5 — Install
- Open the downloaded APK from your Downloads/Files app
- Allow "install unknown apps" for your browser if prompted
- Open the app, set up the Telegram bot (instructions are inside the app),
  enable forwarding, grant SMS permission

---

## Fallback: Termux method (if folder upload doesn't work)
If GitHub's mobile upload won't take whole folders, install **Termux**
(from F-Droid, not the outdated Play Store version), then in Termux:

```
pkg install git -y
cd storage/downloads     # or wherever you unzipped/extracted the project
git init
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/sms-to-telegram.git
git add .
git commit -m "initial commit"
git push -u origin main
```
It will ask for your GitHub username and a **Personal Access Token** (not
your password) — create one at github.com → Settings → Developer settings
→ Personal access tokens → generate (check the "repo" scope), then paste
it as the password when Termux prompts you.

Once pushed, continue from Step 4 above.
