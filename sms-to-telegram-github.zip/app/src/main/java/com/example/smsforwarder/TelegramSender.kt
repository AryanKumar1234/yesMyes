package com.example.smsforwarder

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object TelegramSender {
    private val pool = Executors.newCachedThreadPool()

    fun send(token: String, chatId: String, text: String, onDone: ((Boolean, String) -> Unit)? = null) {
        pool.execute {
            try {
                val url = URL("https://api.telegram.org/bot$token/sendMessage")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.connectTimeout = 15000
                conn.readTimeout = 15000

                val params = "chat_id=" + URLEncoder.encode(chatId, "UTF-8") +
                        "&text=" + URLEncoder.encode(text, "UTF-8")
                conn.outputStream.use { it.write(params.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream?.bufferedReader()?.readText() ?: ""
                conn.disconnect()

                onDone?.invoke(code in 200..299, if (code in 200..299) "OK" else "HTTP $code: $resp")
            } catch (e: Exception) {
                onDone?.invoke(false, e.message ?: "error")
            }
        }
    }
}
