package com.onion.yesmyes

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val useTelegram = prefs.getBoolean("use_telegram", false)
        val token = prefs.getString("bot_token", "")?.trim().orEmpty()
        val chatId = prefs.getString("chat_id", "")?.trim().orEmpty()

        if (!useTelegram || token.isEmpty() || chatId.isEmpty()) return

        // Extend the broadcast's lifetime for the network call, same pattern
        // as SmsReceiver. No persistent service, no notification — this just
        // sends one message confirming the device came back online.
        val pendingResult = goAsync()
        Thread {
            try {
                val deviceName = TelegramSender.effectiveDeviceName(context)
                val enabled = prefs.getBoolean("enabled", false)
                TelegramSender.announce(token, chatId, "$deviceName (rebooted)", enabled)
            } finally {
                pendingResult.finish()
            }
        }.start()
    }
}
