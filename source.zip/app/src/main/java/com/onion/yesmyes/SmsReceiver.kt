package com.onion.yesmyes

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsManager

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val useTelegram = prefs.getBoolean("use_telegram", false)
        val token = prefs.getString("bot_token", "")?.trim().orEmpty()
        val chatId = prefs.getString("chat_id", "")?.trim().orEmpty()
        val useNtfy = prefs.getBoolean("use_ntfy", false)
        val ntfyTopic = prefs.getString("ntfy_topic", "")?.trim().orEmpty()

        // Extend the broadcast's lifetime so we can do a network call (the
        // Telegram command check) before deciding whether to forward at all.
        val pendingResult = goAsync()

        Thread {
            try {
                // Check for a remote /start or /stop before reading the master
                // switch, so a command can flip it in either direction right
                // before this decides whether to forward.
                if (useTelegram && token.isNotEmpty() && chatId.isNotEmpty()) {
                    TelegramSender.checkAndUpdateMasterSwitch(context, token, chatId)
                }
                if (useNtfy && ntfyTopic.isNotEmpty()) {
                    NtfySender.checkAndUpdateMasterSwitch(context, ntfyTopic)
                }

                if (!prefs.getBoolean("enabled", false)) return@Thread

                val useSms = prefs.getBoolean("use_sms", false)
                val smsTarget = prefs.getString("sms_target", "")?.trim().orEmpty()

                if (!useSms && !useTelegram && !useNtfy) return@Thread

                val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return@Thread
                val grouped = messages.groupBy { it.originatingAddress ?: "Unknown" }
                val deviceName = TelegramSender.effectiveDeviceName(context)

                for ((sender, parts) in grouped) {
                    val body = parts.joinToString("") { it.messageBody ?: "" }

                    if (useSms && smsTarget.isNotEmpty()) {
                        val smsText = "From $sender:\n$body"
                        try {
                            val sms = context.getSystemService(SmsManager::class.java)
                            sms.sendMultipartTextMessage(smsTarget, null, sms.divideMessage(smsText), null, null)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    if (useTelegram && token.isNotEmpty() && chatId.isNotEmpty()) {
                        val tgText = "\uD83D\uDCF1 $deviceName\n\uD83D\uDCE9 From $sender:\n$body"
                        TelegramSender.send(token, chatId, tgText)
                    }

                    if (useNtfy && ntfyTopic.isNotEmpty()) {
                        val ntfyText = "From $sender:\n$body"
                        NtfySender.send(ntfyTopic, ntfyText, title = deviceName)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }.start()
    }
}
