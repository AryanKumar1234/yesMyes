package com.onion.yesmyes

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun sectionLabel(text: String) = TextView(this).apply {
            this.text = text
            textSize = 16f
            setPadding(0, pad, 0, pad / 4)
        }

        val deviceNameField = EditText(this).apply {
            hint = android.os.Build.MODEL
            setText(prefs.getString("device_name", ""))
        }

        // --- SMS channel ---
        val useSmsBox = CheckBox(this).apply {
            text = "Forward via SMS"
            isChecked = prefs.getBoolean("use_sms", false)
        }
        val smsTargetField = EditText(this).apply {
            hint = "Forward to phone number (e.g. +15551234567)"
            inputType = InputType.TYPE_CLASS_PHONE
            setText(prefs.getString("sms_target", ""))
        }

        // --- Telegram channel ---
        val useTelegramBox = CheckBox(this).apply {
            text = "Forward via Telegram"
            isChecked = prefs.getBoolean("use_telegram", false)
        }
        val telegramWarning = TextView(this).apply {
            text = "⚠️ Telegram may flag or freeze bots that forward verification " +
                "codes (OTPs). If this happens, the bot token stops working and " +
                "you'll need to create a new one via @BotFather."
            setTextColor(0xFFE0A030.toInt())
            textSize = 13f
            setPadding(0, 0, 0, pad / 4)
        }
        val tokenField = EditText(this).apply {
            hint = "Bot token (from @BotFather)"
            setText(prefs.getString("bot_token", ""))
        }
        val chatIdField = EditText(this).apply {
            hint = "Chat ID (from @userinfobot)"
            setText(prefs.getString("chat_id", ""))
        }

        // --- ntfy channel ---
        val useNtfyBox = CheckBox(this).apply {
            text = "Forward via ntfy.sh  (Recommended)"
            isChecked = prefs.getBoolean("use_ntfy", false)
            setTextColor(0xFF4CAF50.toInt())
        }
        val ntfyTopicField = EditText(this).apply {
            hint = "ntfy topic (e.g. my-sms-xyz123)"
            setText(prefs.getString("ntfy_topic", ""))
        }

        val toggle = Switch(this).apply {
            text = "Forwarding enabled  "
            isChecked = prefs.getBoolean("enabled", false)
        }
        val startStopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, pad / 2, 0, 0)
        }
        val startButton = Button(this).apply { text = "Start" }
        val stopButton = Button(this).apply { text = "Stop" }

        val save = Button(this).apply { text = "Save" }
        val test = Button(this).apply { text = "Send test message" }
        val status = TextView(this).apply { setPadding(0, pad / 2, 0, 0) }

        fun save() {
            prefs.edit()
                .putString("device_name", deviceNameField.text.toString().trim())
                .putBoolean("use_sms", useSmsBox.isChecked)
                .putString("sms_target", smsTargetField.text.toString().trim())
                .putBoolean("use_telegram", useTelegramBox.isChecked)
                .putString("bot_token", tokenField.text.toString().trim())
                .putString("chat_id", chatIdField.text.toString().trim())
                .putBoolean("use_ntfy", useNtfyBox.isChecked)
                .putString("ntfy_topic", ntfyTopicField.text.toString().trim())
                .putBoolean("enabled", toggle.isChecked)
                .apply()
        }

        fun announceIfTelegram() {
            if (useTelegramBox.isChecked) {
                TelegramSender.announce(
                    tokenField.text.toString().trim(),
                    chatIdField.text.toString().trim(),
                    TelegramSender.effectiveDeviceName(this),
                    toggle.isChecked
                )
            }
        }

        save.setOnClickListener {
            if (!hasPerms()) { askPerms(); return@setOnClickListener }
            save()
            announceIfTelegram()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        startButton.setOnClickListener {
            if (!hasPerms()) { askPerms(); return@setOnClickListener }
            toggle.isChecked = true
            save()
            announceIfTelegram()
            Toast.makeText(this, "Forwarding started", Toast.LENGTH_SHORT).show()
        }

        stopButton.setOnClickListener {
            toggle.isChecked = false
            save()
            announceIfTelegram()
            Toast.makeText(this, "Forwarding stopped", Toast.LENGTH_SHORT).show()
        }

        test.setOnClickListener {
            save()
            val deviceName = TelegramSender.effectiveDeviceName(this)
            var firedAny = false

            if (useTelegramBox.isChecked) {
                val token = tokenField.text.toString().trim()
                val chatId = chatIdField.text.toString().trim()
                if (token.isNotEmpty() && chatId.isNotEmpty()) {
                    firedAny = true
                    status.text = "Sending via Telegram..."
                    TelegramSender.send(token, chatId, "✅ Test message ($deviceName)") { ok, msg ->
                        runOnUiThread { status.text = "Telegram: " + (if (ok) "Sent!" else "Failed: $msg") }
                    }
                }
            }
            if (useNtfyBox.isChecked) {
                val topic = ntfyTopicField.text.toString().trim()
                if (topic.isNotEmpty()) {
                    firedAny = true
                    NtfySender.send(topic, "✅ Test message ($deviceName)", title = deviceName) { ok, msg ->
                        runOnUiThread {
                            val prev = status.text.toString()
                            status.text = prev + "\nntfy: " + (if (ok) "Sent!" else "Failed: $msg")
                        }
                    }
                }
            }
            if (!firedAny) {
                Toast.makeText(this, "Enable and fill in at least one channel first", Toast.LENGTH_SHORT).show()
            }
        }

        val note = TextView(this).apply {
            val prefix = "\nSetup instructions: "
            val linkWord = "Here"
            val full = prefix + linkWord
            val spannable = android.text.SpannableString(full)
            spannable.setSpan(
                object : android.text.style.ClickableSpan() {
                    override fun onClick(widget: android.view.View) {
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://github.com/AryanKumar1234/yesMyes")
                        )
                        startActivity(intent)
                    }
                },
                prefix.length, full.length,
                android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            text = spannable
            movementMethod = android.text.method.LinkMovementMethod.getInstance()
        }

        val footer = TextView(this).apply {
            text = "Created by The AryanOnion"
            setPadding(0, pad, 0, 0)
            alpha = 0.8f
            setTextColor(0xFF3391FF.toInt())
            setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/AryanKumar1234"))
                startActivity(intent)
            }
        }

        startStopRow.addView(startButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginEnd = pad / 4 })
        startStopRow.addView(stopButton, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { marginStart = pad / 4 })

        listOf(
            sectionLabel("Device"), deviceNameField,
            sectionLabel("SMS"), useSmsBox, smsTargetField,
            sectionLabel("Telegram"), useTelegramBox, telegramWarning, tokenField, chatIdField,
            sectionLabel("ntfy.sh"), useNtfyBox, ntfyTopicField,
            toggle, startStopRow, save, test, status, note, footer
        ).forEach {
            root.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        if (!hasPerms()) askPerms()

        val savedToken = prefs.getString("bot_token", "")?.trim().orEmpty()
        val savedChatId = prefs.getString("chat_id", "")?.trim().orEmpty()
        if (prefs.getBoolean("use_telegram", false) && savedToken.isNotEmpty() && savedChatId.isNotEmpty()) {
            TelegramSender.announce(
                savedToken,
                savedChatId,
                TelegramSender.effectiveDeviceName(this),
                prefs.getBoolean("enabled", false)
            )
        }
    }

    private val perms = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS)

    private fun hasPerms() = perms.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun askPerms() = ActivityCompat.requestPermissions(this, perms, 1)
}
