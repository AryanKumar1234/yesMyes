package com.onion.yesmyes

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.Telephony
import androidx.core.app.NotificationManagerCompat
import androidx.activity.result.contract.ActivityResultContracts
import android.text.InputType
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var syncStatus: TextView? = null
    private var waStatus: TextView? = null

    private fun updateWaStatus() {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val granted = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        waStatus?.text = when {
            !prefs.getBoolean("use_whatsapp", false) -> ""
            granted -> "Notification access granted - WhatsApp forwarding is active."
            else -> "Notification access NOT granted yet. Tap the button below and enable it for this app."
        }
    }

    override fun onResume() {
        super.onResume()
        updateWaStatus()
    }

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        updateSyncStatus()
    }

    private fun updateSyncStatus() {
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        if (!prefs.getBoolean("sync_delete", false)) { syncStatus?.text = ""; return }
        val pending = SmsDeleter.pendingCount(this)
        syncStatus?.text = if (SmsDeleter.isDefault(this))
            "Delete sync active (this app is the default SMS app)." +
                (if (pending > 0) " $pending deletion(s) pending." else "")
        else
            "Delete sync needs this app to be the default SMS app. Tap the checkbox again to set it." +
                (if (pending > 0) " $pending deletion(s) waiting." else "")
    }

    private fun requestDefaultSms() {
        if (SmsDeleter.isDefault(this)) return
        val intent = if (Build.VERSION.SDK_INT >= 29) {
            getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS)
        } else {
            Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
        }
        roleLauncher.launch(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun sectionLabel(text: String) = TextView(this).apply {
            this.text = text
            textSize = 16f
            setPadding(0, pad, 0, pad / 4)
        }

        val deviceNameField = EditText(this).apply {
            hint = android.os.Build.MODEL
            setText(prefs.getString("device_name", ""))
        }

        // --- SMS channel ---
        val useSmsBox = CheckBox(this).apply {
            text = "Forward via SMS"
            isChecked = prefs.getBoolean("use_sms", false)
        }
        val smsTargetField = EditText(this).apply {
            hint = "Forward to phone number (e.g. +15551234567)"
            inputType = InputType.TYPE_CLASS_PHONE
            setText(prefs.getString("sms_target", ""))
        }

        // --- Telegram channel ---
        val useTelegramBox = CheckBox(this).apply {
            text = "Forward via Telegram"
            isChecked = prefs.getBoolean("use_telegram", false)
        }
        val telegramWarning = TextView(this).apply {
            text = "⚠️ Telegram may flag or freeze bots that forward verification " +
                "codes (OTPs). If this happens, the bot token stops working and " +
                "you'll need to create a new one via @BotFather."
            setTextColor(0xFFE0A030.toInt())
            textSize = 13f
            setPadding(0, 0, 0, pad / 4)
        }
        val tokenField = EditText(this).apply {
            hint = "Bot token (from @BotFather)"
            setText(prefs.getString("bot_token", ""))
        }
        val chatIdField = EditText(this).apply {
            hint = "Chat ID (from @userinfobot)"
            setText(prefs.getString("chat_id", ""))
        }

        // --- ntfy channel ---
        val useNtfyBox = CheckBox(this).apply {
            text = "Forward via ntfy.sh  (Recommended)"
            isChecked = prefs.getBoolean("use_ntfy", false)
            setTextColor(0xFF4CAF50.toInt())
        }
        val ntfyTopicField = EditText(this).apply {
            hint = "ntfy topic (e.g. my-sms-xyz123)"
            setText(prefs.getString("ntfy_topic", ""))
        }

        val syncDeleteBox = CheckBox(this).apply {
            text = "Delete SMS on this phone when I delete it on ntfy"
            isChecked = prefs.getBoolean("sync_delete", false)
        }
        val syncNote = TextView(this).apply {
            text = "Android only lets the default SMS app delete texts, so this makes " +
                "YesMyes your default SMS app (new texts are still saved to the inbox, but " +
                "your normal Messages app won't get new SMS or MMS, and you'll get no new-SMS " +
                "notification). Each forwarded text gets an ID and a \"Delete from phone\" button in ntfy; " +
                "you can also publish \"/delete <ID>\" to your topic. " +
                "Deletions are applied within ~15 min or when the next SMS arrives."
            textSize = 13f
            setPadding(0, 0, 0, pad / 4)
        }
        syncStatus = TextView(this).apply { textSize = 13f }
        syncDeleteBox.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("sync_delete", checked).apply()
            SyncWorker.schedule(this, checked && useNtfyBox.isChecked)
            if (checked) requestDefaultSms()
            updateSyncStatus()
        }

        // --- WhatsApp ---
        val useWhatsAppBox = CheckBox(this).apply {
            text = "Forward WhatsApp messages"
            isChecked = prefs.getBoolean("use_whatsapp", false)
        }
        val waNote = TextView(this).apply {
            text = "Reads WhatsApp's notifications (needs Notification access), so only the " +
                "sender/group and message preview are forwarded. Muted chats, hidden " +
                "notifications, or messages you already read on another device may not " +
                "be forwarded; media shows as e.g. \"Photo\"."
            textSize = 13f
            setPadding(0, 0, 0, pad / 4)
        }
        val waGrant = Button(this).apply {
            text = "Grant notification access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        waStatus = TextView(this).apply { textSize = 13f }
        useWhatsAppBox.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("use_whatsapp", checked).apply()
            updateWaStatus()
        }

        val toggle = Switch(this).apply {
            text = "Forwarding enabled  "
            isChecked = prefs.getBoolean("enabled", false)
        }
        val save = Button(this).apply { text = "Save" }
        val test = Button(this).apply { text = "Send test message" }
        val status = TextView(this).apply { setPadding(0, pad / 2, 0, 0) }

        fun save() {
            prefs.edit()
                .putString("device_name", deviceNameField.text.toString().trim())
                .putBoolean("use_sms", useSmsBox.isChecked)
                .putString("sms_target", smsTargetField.text.toString().trim())
                .putBoolean("use_telegram", useTelegramBox.isChecked)
                .putString("bot_token", tokenField.text.toString().trim())
                .putString("chat_id", chatIdField.text.toString().trim())
                .putBoolean("use_ntfy", useNtfyBox.isChecked)
                .putString("ntfy_topic", ntfyTopicField.text.toString().trim())
                .putBoolean("enabled", toggle.isChecked)
                .putBoolean("sync_delete", syncDeleteBox.isChecked)
                .putBoolean("use_whatsapp", useWhatsAppBox.isChecked)
                .apply()
            SyncWorker.schedule(this, syncDeleteBox.isChecked && useNtfyBox.isChecked)
        }

        fun announceIfTelegram() {
            if (useTelegramBox.isChecked) {
                TelegramSender.announce(
                    tokenField.text.toString().trim(),
                    chatIdField.text.toString().trim(),
                    TelegramSender.effectiveDeviceName(this),
                    toggle.isChecked
                )
            }
        }

        save.setOnClickListener {
            if (!hasPerms()) { askPerms(); return@setOnClickListener }
            save()
            announceIfTelegram()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        test.setOnClickListener {
            save()
            val deviceName = TelegramSender.effectiveDeviceName(this)
            var firedAny = false

            if (useTelegramBox.isChecked) {
                val token = tokenField.text.toString().trim()
                val chatId = chatIdField.text.toString().trim()
                if (token.isNotEmpty() && chatId.isNotEmpty()) {
                    firedAny = true
                    status.text = "Sending via Telegram..."
                    TelegramSender.send(token, chatId, "✅ Test message ($deviceName)") { ok, msg ->
                        runOnUiThread { status.text = "Telegram: " + (if (ok) "Sent!" else "Failed: $msg") }
                    }
                }
            }
            if (useNtfyBox.isChecked) {
                val topic = ntfyTopicField.text.toString().trim()
                if (topic.isNotEmpty()) {
                    firedAny = true
                    NtfySender.send(topic, "✅ Test message ($deviceName)", title = deviceName) { ok, msg ->
                        runOnUiThread {
                            val prev = status.text.toString()
                            status.text = prev + "\nntfy: " + (if (ok) "Sent!" else "Failed: $msg")
                        }
                    }
                }
            }
            if (!firedAny) {
                Toast.makeText(this, "Enable and fill in at least one channel first", Toast.LENGTH_SHORT).show()
            }
        }

        listOf(
            sectionLabel("Device"), deviceNameField,
            sectionLabel("SMS"), useSmsBox, smsTargetField,
            sectionLabel("Telegram"), useTelegramBox, telegramWarning, tokenField, chatIdField,
            sectionLabel("ntfy.sh"), useNtfyBox, ntfyTopicField,
            syncDeleteBox, syncNote, syncStatus!!,
            sectionLabel("WhatsApp"), useWhatsAppBox, waNote, waGrant, waStatus!!,
            toggle, save, test, status
        ).forEach {
            root.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        if (!hasPerms()) askPerms()

        // Apply any ntfy deletions right away if we're allowed to.
        if (prefs.getBoolean("sync_delete", false)) {
            SyncWorker.schedule(this, prefs.getBoolean("use_ntfy", false))
            val topic = prefs.getString("ntfy_topic", "")?.trim().orEmpty()
            if (prefs.getBoolean("use_ntfy", false) && topic.isNotEmpty()) {
                Thread {
                    NtfySender.checkAndUpdateMasterSwitch(applicationContext, topic)
                    SmsDeleter.processPending(applicationContext)
                    runOnUiThread { updateSyncStatus() }
                }.start()
            }
        }
        updateSyncStatus()

        val savedToken = prefs.getString("bot_token", "")?.trim().orEmpty()
        val savedChatId = prefs.getString("chat_id", "")?.trim().orEmpty()
        if (prefs.getBoolean("use_telegram", false) && savedToken.isNotEmpty() && savedChatId.isNotEmpty()) {
            TelegramSender.announce(
                savedToken,
                savedChatId,
                TelegramSender.effectiveDeviceName(this),
                prefs.getBoolean("enabled", false)
            )
        }
    }

    private val perms = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS)

    private fun hasPerms() = perms.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun askPerms() = ActivityCompat.requestPermissions(this, perms, 1)
}
