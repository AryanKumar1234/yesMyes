package com.onion.yesmyes

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telephony.SmsManager

/**
 * Forwards incoming WhatsApp messages by reading WhatsApp's notifications
 * (Android's "Notification access"). It can only see what the notification
 * shows: sender/group name and the message preview text.
 */
class WhatsAppListener : NotificationListenerService() {

    private val recent = LinkedHashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg != "com.whatsapp" && pkg != "com.whatsapp.w4b") return

        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("use_whatsapp", false)) return

        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return

        val extras = n.extras ?: return
        var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()

        if (text.isEmpty()) return
        // Generic WhatsApp housekeeping notifications, not real messages.
        if (title.equals("WhatsApp", true) || title.equals("WhatsApp Business", true)) return
        if (Regex("^\\d+ (new )?messages?( from \\d+ chats?)?$", RegexOption.IGNORE_CASE).matches(text)) return
        if (text.equals("Checking for new messages", true)) return

        // "Alice (3 messages)" -> "Alice"
        title = title.replace(Regex("\\s*\\(\\d+ messages?\\)$"), "")

        // WhatsApp re-posts the same notification when it updates; forward each message once.
        val dedupeKey = "${sbn.key}|${n.`when`}|${text.hashCode()}"
        synchronized(recent) {
            val now = System.currentTimeMillis()
            recent.entries.removeAll { now - it.value > 10 * 60 * 1000L }
            if (recent.containsKey(dedupeKey)) return
            recent[dedupeKey] = now
            while (recent.size > 200) recent.remove(recent.keys.first())
        }

        val app = if (pkg == "com.whatsapp.w4b") "WhatsApp Business" else "WhatsApp"
        val ctx = applicationContext

        Thread {
            val useTelegram = prefs.getBoolean("use_telegram", false)
            val token = prefs.getString("bot_token", "")?.trim().orEmpty()
            val chatId = prefs.getString("chat_id", "")?.trim().orEmpty()
            val useNtfy = prefs.getBoolean("use_ntfy", false)
            val topic = prefs.getString("ntfy_topic", "")?.trim().orEmpty()
            val useSms = prefs.getBoolean("use_sms", false)
            val smsTarget = prefs.getString("sms_target", "")?.trim().orEmpty()

            // Honour remote /start and /stop before forwarding, same as SMS.
            if (useTelegram && token.isNotEmpty() && chatId.isNotEmpty()) {
                TelegramSender.checkAndUpdateMasterSwitch(ctx, token, chatId)
            }
            if (useNtfy && topic.isNotEmpty()) {
                NtfySender.checkAndUpdateMasterSwitch(ctx, topic)
            }
            if (!prefs.getBoolean("enabled", false)) return@Thread

            val deviceName = TelegramSender.effectiveDeviceName(ctx)
            val body = "From $title:\n$text"

            if (useSms && smsTarget.isNotEmpty()) {
                try {
                    val sms = ctx.getSystemService(SmsManager::class.java)
                    sms.sendMultipartTextMessage(
                        smsTarget, null, sms.divideMessage("$app $body"), null, null
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            if (useTelegram && token.isNotEmpty() && chatId.isNotEmpty()) {
                TelegramSender.send(token, chatId, "\uD83D\uDCF1 $deviceName\n\uD83D\uDCAC $app\n$body")
            }
            if (useNtfy && topic.isNotEmpty()) {
                NtfySender.send(topic, "$app\n$body", title = deviceName)
            }
        }.start()
    }
}
