package com.onion.yesmyes

import android.content.Context
import android.net.Uri
import android.provider.BaseColumns
import android.provider.Telephony
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Remembers which forwarded ntfy notification belongs to which SMS, and deletes
 * that SMS from the phone's inbox once the notification is deleted on ntfy.
 *
 * Only a hash of the body is stored (never the text). Deleting from the inbox
 * only works while this app is the default SMS app (Android restriction).
 */
object SmsDeleter {
    private val lock = Any()
    private const val MAP = "sms_map"
    private const val PENDING = "sms_pending"
    private const val MAX_ENTRIES = 300
    private const val WINDOW_MS = 3 * 60 * 1000L

    private const val CODE_CHARS = "abcdefghjkmnpqrstuvwxyz23456789"

    /** Short, unique, easy-to-type code shown in each forwarded message (e.g. "k7f2xq"). */
    fun newCode(context: Context): String {
        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val map = try { JSONObject(prefs.getString(MAP, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val rnd = java.security.SecureRandom()
        while (true) {
            val code = (1..6).map { CODE_CHARS[rnd.nextInt(CODE_CHARS.length)] }.joinToString("")
            if (!map.has(seqFor(code))) return code
        }
    }

    /** ntfy sequence id for a code. Accepts "K7F2XQ", "k7f2xq" or "sms-k7f2xq". */
    fun seqFor(code: String): String {
        val c = code.trim().lowercase().removePrefix("sms-")
        return "sms-$c"
    }

    fun isDefault(context: Context): Boolean =
        Telephony.Sms.getDefaultSmsPackage(context) == context.packageName

    fun syncEnabled(context: Context): Boolean =
        context.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("sync_delete", false)

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    /** Call when an SMS is forwarded to ntfy under sequence id [seq]. */
    fun remember(context: Context, seq: String, address: String, body: String) {
        synchronized(lock) {
            val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            val map = try { JSONObject(prefs.getString(MAP, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
            map.put(seq, JSONObject().put("a", address).put("h", sha(body)).put("t", System.currentTimeMillis()))

            // Keep the map bounded: drop the oldest entries.
            while (map.length() > MAX_ENTRIES) {
                var oldestKey: String? = null
                var oldestT = Long.MAX_VALUE
                val keys = map.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val t = map.optJSONObject(k)?.optLong("t", 0L) ?: 0L
                    if (t < oldestT) { oldestT = t; oldestKey = k }
                }
                if (oldestKey == null) break
                map.remove(oldestKey)
            }
            prefs.edit().putString(MAP, map.toString()).apply()
        }
    }

    /** Call when ntfy reports a message_delete for [seq]. Ignored if it isn't one of ours. */
    fun markForDeletion(context: Context, seq: String) {
        synchronized(lock) {
            val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            val map = try { JSONObject(prefs.getString(MAP, "{}") ?: "{}") } catch (e: Exception) { return }
            if (!map.has(seq)) return
            val pending = HashSet(prefs.getStringSet(PENDING, emptySet()) ?: emptySet())
            pending.add(seq)
            prefs.edit().putStringSet(PENDING, pending).apply()
        }
    }

    fun pendingCount(context: Context): Int =
        context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            .getStringSet(PENDING, emptySet())?.size ?: 0

    /** Deletes inbox rows for every pending sequence id. Returns number of SMS removed. */
    fun processPending(context: Context): Int {
        synchronized(lock) {
            val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            val pending = HashSet(prefs.getStringSet(PENDING, emptySet()) ?: emptySet())
            if (pending.isEmpty()) return 0
            // Not the default SMS app: Android forbids deleting. Keep pending for later.
            if (!isDefault(context)) return 0

            val map = try { JSONObject(prefs.getString(MAP, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
            var removed = 0
            val doneSeqs = mutableListOf<String>()

            for (seq in pending.toList()) {
                val entry = map.optJSONObject(seq)
                if (entry == null) { pending.remove(seq); continue }
                val addr = entry.optString("a")
                val hash = entry.optString("h")
                val t = entry.optLong("t")
                try {
                    val ids = ArrayList<Long>()
                    context.contentResolver.query(
                        Telephony.Sms.CONTENT_URI,
                        arrayOf(BaseColumns._ID, Telephony.Sms.BODY),
                        "address=? AND date>=? AND date<=?",
                        arrayOf(addr, (t - WINDOW_MS).toString(), (t + WINDOW_MS).toString()),
                        null
                    )?.use { c ->
                        while (c.moveToNext()) {
                            val body = c.getString(1) ?: ""
                            if (sha(body) == hash) ids.add(c.getLong(0))
                        }
                    }
                    for (id in ids) {
                        removed += context.contentResolver.delete(
                            Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, id.toString()), null, null
                        )
                    }
                    // Done (or the SMS was already gone) — forget it.
                    map.remove(seq)
                    pending.remove(seq)
                    doneSeqs.add(seq)
                } catch (e: Exception) {
                    // Leave it pending and retry next time.
                }
            }
            prefs.edit().putString(MAP, map.toString()).putStringSet(PENDING, pending).apply()

            // Best effort: also remove the notification from ntfy so both sides match.
            val topic = prefs.getString("ntfy_topic", "")?.trim().orEmpty()
            if (topic.isNotEmpty()) doneSeqs.forEach { NtfySender.deleteRemote(topic, it) }
            return removed
        }
    }
}
