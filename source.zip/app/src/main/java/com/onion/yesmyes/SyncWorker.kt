package com.onion.yesmyes

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Every ~15 min: look for deletions made on ntfy and apply them to the SMS inbox. */
class SyncWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val topic = prefs.getString("ntfy_topic", "")?.trim().orEmpty()
        if (prefs.getBoolean("use_ntfy", false) && prefs.getBoolean("sync_delete", false) && topic.isNotEmpty()) {
            NtfySender.checkAndUpdateMasterSwitch(applicationContext, topic)
            SmsDeleter.processPending(applicationContext)
        }
        return Result.success()
    }

    companion object {
        private const val NAME = "ntfy-delete-sync"

        fun schedule(context: Context, on: Boolean) {
            val wm = WorkManager.getInstance(context)
            if (on) {
                val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                    .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                    .build()
                wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
            } else {
                wm.cancelUniqueWork(NAME)
            }
        }
    }
}
