package com.onion.yesmyes

import android.app.Service
import android.content.Intent
import android.os.IBinder

/** Required stub for default-SMS-app eligibility ("quick reply" to a call). */
class RespondViaMessageService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
