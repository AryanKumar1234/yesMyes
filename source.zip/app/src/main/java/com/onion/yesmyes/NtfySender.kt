package com.onion.yesmyes

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object NtfySender {
    private val pool = Executors.newCachedThreadPool()

    /**
     * Polls the ntfy topic for any new messages whose body is a /start or /stop
     * command (optionally "/start <device name>" or "/start all"), and if found,
     * writes directly to the same master "enabled" switch used by the app's own
     * toggle, the Start/Stop buttons, and Telegram's command handling.
     *
     * Synchronous (blocking network call) — call from a background thread,
     * before deciding whether to forward at all.
     */
    fun checkAndUpdateMasterSwitch(context: Context, topic: String) {
        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val since = prefs.getLong("ntfy_since", 0)
        val sinceParam = if (since == 0L) "all" else since.toString()

        try {
            val encodedTopic = URLEncoder.encode(topic, "UTF-8").replace("+", "%20")
            val url = URL("https://ntfy.sh/$encodedTopic/json?poll=1&since=$sinceParam")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 10000

            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return
            }
            val lines = conn.inputStream.bufferedReader().readLines()
            conn.disconnect()

            val deviceName = TelegramSender.effectiveDeviceName(context).lowercase()
            var maxTime = since
            var newState: Boolean? = null

            for (line in lines) {
                if (line.isBlank()) continue
                val obj = try { JSONObject(line) } catch (e: Exception) { continue }
                if (obj.optString("event") != "message") continue

                val time = obj.optLong("time", since)
                if (time > maxTime) maxTime = time

                val raw = obj.optString("message", "").trim()
                if (raw.isEmpty()) continue
                val parts = raw.split(Regex("\\s+"), limit = 2)
                val cmd = parts[0].lowercase()
                val arg = if (parts.size > 1) parts[1].trim().lowercase() else ""

                val appliesToThisDevice = arg.isEmpty() || arg == "all" || arg == deviceName
                if (appliesToThisDevice) {
                    when (cmd) {
                        "/start" -> newState = true
                        "/stop" -> newState = false
                    }
                }
            }

            val editor = prefs.edit()
            editor.putLong("ntfy_since", maxTime + 1)
            if (newState != null) editor.putBoolean("enabled", newState)
            editor.apply()
        } catch (e: Exception) {
            // No network or request failed — leave the master switch as-is.
        }
    }

    fun send(topic: String, text: String, title: String? = null, onDone: ((Boolean, String) -> Unit)? = null) {
        pool.execute {
            try {
                val url = URL("https://ntfy.sh/" + URLEncoder.encode(topic, "UTF-8").replace("+", "%20"))
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
                if (!title.isNullOrBlank()) {
                    // Header values must be Latin-1/ASCII-safe; ntfy recommends URL-encoding non-ASCII titles.
                    conn.setRequestProperty("X-Title", title)
                }
                conn.connectTimeout = 15000
                conn.readTimeout = 15000

                conn.outputStream.use { it.write(text.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream?.bufferedReader()?.readText() ?: ""
                conn.disconnect()

                onDone?.invoke(code in 200..299, if (code in 200..299) "OK" else "HTTP $code: $resp")
            } catch (e: Exception) {
                onDone?.invoke(false, e.message ?: "error")
            }
        }
    }
}
