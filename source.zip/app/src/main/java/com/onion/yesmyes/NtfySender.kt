package com.onion.yesmyes

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object NtfySender {
    private val pool = Executors.newCachedThreadPool()

    /**
     * Polls the ntfy topic for any new messages whose body is a /start or /stop
     * command (optionally "/start <device name>" or "/start all"), and if found,
     * writes directly to the same master "enabled" switch used by the app's own
     * toggle, the Start/Stop buttons, and Telegram's command handling.
     *
     * Synchronous (blocking network call) — call from a background thread,
     * before deciding whether to forward at all.
     */
    fun checkAndUpdateMasterSwitch(context: Context, topic: String) {
        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val since = prefs.getLong("ntfy_since", 0)
        val sinceParam = if (since == 0L) "all" else since.toString()

        try {
            val encodedTopic = URLEncoder.encode(topic, "UTF-8").replace("+", "%20")
            val url = URL("https://ntfy.sh/$encodedTopic/json?poll=1&since=$sinceParam")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 10000
            conn.readTimeout = 10000

            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return
            }
            val lines = conn.inputStream.bufferedReader().readLines()
            conn.disconnect()

            val deviceName = TelegramSender.effectiveDeviceName(context).lowercase()
            var maxTime = since
            var newState: Boolean? = null
            val deletedSeqs = mutableListOf<String>()

            for (line in lines) {
                if (line.isBlank()) continue
                val obj = try { JSONObject(line) } catch (e: Exception) { continue }
                val time = obj.optLong("time", since)
                if (time > maxTime) maxTime = time

                // A notification was deleted on ntfy -> queue the matching SMS for deletion.
                if (obj.optString("event") == "message_delete") {
                    val sid = obj.optString("sequence_id", "")
                    if (sid.isNotEmpty()) deletedSeqs.add(sid)
                    continue
                }
                if (obj.optString("event") != "message") continue

                val raw = obj.optString("message", "").trim()
                if (raw.isEmpty()) continue
                val parts = raw.split(Regex("\\s+"), limit = 2)
                val cmd = parts[0].lowercase()
                val arg = if (parts.size > 1) parts[1].trim().lowercase() else ""

                // "/delete <code> [<code> ...]" (or just "delete <code>") typed/published into the topic.
                if ((cmd == "/delete" || cmd == "delete") && arg.isNotEmpty()) {
                    arg.split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
                        .forEach { deletedSeqs.add(SmsDeleter.seqFor(it)) }
                    continue
                }

                val appliesToThisDevice = arg.isEmpty() || arg == "all" || arg == deviceName
                if (appliesToThisDevice) {
                    when (cmd) {
                        "/start" -> newState = true
                        "/stop" -> newState = false
                    }
                }
            }

            val editor = prefs.edit()
            editor.putLong("ntfy_since", maxTime + 1)
            if (newState != null) editor.putBoolean("enabled", newState)
            editor.apply()

            deletedSeqs.forEach { SmsDeleter.markForDeletion(context, it) }
        } catch (e: Exception) {
            // No network or request failed — leave the master switch as-is.
        }
    }

    /** Removes a notification (sequence) from ntfy. Blocking; call off the main thread. */
    fun deleteRemote(topic: String, sequenceId: String) {
        try {
            val enc = URLEncoder.encode(topic, "UTF-8").replace("+", "%20")
            val conn = URL("https://ntfy.sh/$enc/$sequenceId").openConnection() as HttpURLConnection
            conn.requestMethod = "DELETE"
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.responseCode
            conn.disconnect()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun send(
        topic: String,
        text: String,
        title: String? = null,
        sequenceId: String? = null,
        onDone: ((Boolean, String) -> Unit)? = null
    ) {
        pool.execute {
            try {
                val url = URL("https://ntfy.sh/" + URLEncoder.encode(topic, "UTF-8").replace("+", "%20"))
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
                if (!title.isNullOrBlank()) {
                    // Header values must be Latin-1/ASCII-safe; ntfy recommends URL-encoding non-ASCII titles.
                    conn.setRequestProperty("X-Title", title)
                }
                if (!sequenceId.isNullOrBlank()) {
                    // Lets ntfy (and its clients) address this one notification later.
                    conn.setRequestProperty("X-Sequence-ID", sequenceId)
                    // One-tap "delete" button in the ntfy app: sends HTTP DELETE for this
                    // sequence, which makes ntfy emit a message_delete event.
                    val enc = URLEncoder.encode(topic, "UTF-8").replace("+", "%20")
                    conn.setRequestProperty(
                        "X-Actions",
                        "http, Delete from phone, https://ntfy.sh/$enc/$sequenceId, method=DELETE"
                    )
                }
                conn.connectTimeout = 15000
                conn.readTimeout = 15000

                conn.outputStream.use { it.write(text.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resp = stream?.bufferedReader()?.readText() ?: ""
                conn.disconnect()

                onDone?.invoke(code in 200..299, if (code in 200..299) "OK" else "HTTP $code: $resp")
            } catch (e: Exception) {
                onDone?.invoke(false, e.message ?: "error")
            }
        }
    }
}
