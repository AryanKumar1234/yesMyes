package com.onion.yesmyes

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Required stub so Android accepts this app as a default SMS app. MMS is not handled. */
class MmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { /* intentionally empty */ }
}
