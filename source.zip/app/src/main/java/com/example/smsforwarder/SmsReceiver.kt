package com.example.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        val token = prefs.getString("bot_token", "")?.trim().orEmpty()
        val chatId = prefs.getString("chat_id", "")?.trim().orEmpty()
        if (token.isEmpty() || chatId.isEmpty()) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val grouped = messages.groupBy { it.originatingAddress ?: "Unknown" }

        val deviceName = TelegramSender.effectiveDeviceName(context)

        for ((sender, parts) in grouped) {
            val body = parts.joinToString("") { it.messageBody ?: "" }
            val text = "\uD83D\uDCF1 $deviceName\n\uD83D\uDCE9 From $sender:\n$body"
            TelegramSender.forward(context, token, chatId, text)
        }
    }
}
