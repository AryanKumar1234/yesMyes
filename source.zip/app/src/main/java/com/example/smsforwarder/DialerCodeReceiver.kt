package com.example.smsforwarder   // same as BootReceiver's package

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class DialerCodeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val launch = Intent(context, MainActivity::class.java)
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
    }
}