package com.example.smsforwarder

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object TelegramSender {
    private val pool = Executors.newCachedThreadPool()

    /** The name to show/match for this device: the user's saved name, or the
     *  phone's model if that field was left blank. */
    fun effectiveDeviceName(context: Context): String {
        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val stored = prefs.getString("device_name", "")?.trim().orEmpty()
        return stored.ifEmpty { android.os.Build.MODEL }
    }

    /** Pings Telegram to announce this device is configured/online, with its
     *  current forwarding state. Used on app open and after Save, so the chat
     *  builds up a visible history of which devices are set up. */
    fun announce(token: String, chatId: String, deviceName: String, enabled: Boolean) {
        if (token.isEmpty() || chatId.isEmpty()) return
        val status = if (enabled) "ON" else "OFF"
        val text = "\uD83D\uDCF1 $deviceName is online\nForwarding: $status"
        pool.execute { sendMessage(token, chatId, text) }
    }

    /** Used by the "Send test message" button: always sends, ignoring the /start-/stop state. */
    fun send(token: String, chatId: String, text: String, onDone: ((Boolean, String) -> Unit)? = null) {
        pool.execute {
            val (ok, msg) = sendMessage(token, chatId, text)
            onDone?.invoke(ok, msg)
        }
    }

    /**
     * Used by the SMS receiver: first checks Telegram for any new /start or /stop
     * commands from this chat (optionally targeted at a specific device name),
     * updates the saved on/off state, then only sends the forwarded message if
     * currently enabled.
     */
    fun forward(context: Context, token: String, chatId: String, text: String) {
        pool.execute {
            try {
                checkCommands(context, token, chatId)
            } catch (e: Exception) {
                // If the command check fails (e.g. no network), fall back to
                // whatever state was last known rather than blocking forwarding.
            }
            val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
            val enabled = prefs.getBoolean("tg_enabled", true)
            if (enabled) {
                sendMessage(token, chatId, text)
            }
        }
    }

    private fun checkCommands(context: Context, token: String, chatId: String) {
        val prefs = context.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val offset = prefs.getLong("update_offset", 0)

        val url = URL("https://api.telegram.org/bot$token/getUpdates?offset=$offset&timeout=0")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 10000
        conn.readTimeout = 10000

        val code = conn.responseCode
        if (code !in 200..299) {
            conn.disconnect()
            return
        }
        val resp = conn.inputStream.bufferedReader().readText()
        conn.disconnect()

        val deviceName = effectiveDeviceName(context).lowercase()

        val results = JSONObject(resp).optJSONArray("result") ?: return
        var maxUpdateId = offset - 1
        var newState: Boolean? = null

        for (i in 0 until results.length()) {
            val update = results.getJSONObject(i)
            val updateId = update.getLong("update_id")
            if (updateId > maxUpdateId) maxUpdateId = updateId

            val message = update.optJSONObject("message") ?: continue
            val msgChatId = message.optJSONObject("chat")?.optLong("id")?.toString()
            if (msgChatId != chatId) continue

            val raw = message.optString("text", "").trim()
            if (raw.isEmpty()) continue
            val parts = raw.split(Regex("\\s+"), limit = 2)
            val cmd = parts[0].lowercase()
            val arg = if (parts.size > 1) parts[1].trim().lowercase() else ""

            // No argument or "all" applies to every device; otherwise it must
            // match this device's own name to take effect.
            val appliesToThisDevice = arg.isEmpty() || arg == "all" || arg == deviceName

            if (appliesToThisDevice) {
                when (cmd) {
                    "/start" -> newState = true
                    "/stop" -> newState = false
                }
            }
        }

        val editor = prefs.edit()
        editor.putLong("update_offset", maxUpdateId + 1)
        if (newState != null) editor.putBoolean("tg_enabled", newState)
        editor.apply()
    }

    private fun sendMessage(token: String, chatId: String, text: String): Pair<Boolean, String> {
        return try {
            val url = URL("https://api.telegram.org/bot$token/sendMessage")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.connectTimeout = 15000
            conn.readTimeout = 15000

            val params = "chat_id=" + URLEncoder.encode(chatId, "UTF-8") +
                    "&text=" + URLEncoder.encode(text, "UTF-8")
            conn.outputStream.use { it.write(params.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader()?.readText() ?: ""
            conn.disconnect()

            Pair(code in 200..299, if (code in 200..299) "OK" else "HTTP $code: $resp")
        } catch (e: Exception) {
            Pair(false, e.message ?: "error")
        }
    }
}
