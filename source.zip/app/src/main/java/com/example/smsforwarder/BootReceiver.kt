package com.example.smsforwarder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // No action needed here: the manifest-declared SmsReceiver already
        // stays registered across reboots once the app has been opened once.
        // This receiver exists only in case future logic needs a boot hook.
    }
}
